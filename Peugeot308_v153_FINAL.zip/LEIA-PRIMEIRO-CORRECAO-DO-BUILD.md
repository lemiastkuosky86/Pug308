# Correção direta da falha `mipmap/ic_launcher not found` — v1.53

**O erro do log de 14/11/2026** ocorre em `:app:processDebugResources`: o manifesto referencia `@mipmap/ic_launcher`, mas o repositório efetivamente compilado não contém esse recurso.

## O que mudou

- `app/src/main/AndroidManifest.xml`: removidos `android:icon` e `android:roundIcon`. Isso elimina a dependência do recurso ausente **mesmo que a pasta `res/mipmap` não seja enviada**.
- `.github/workflows/compilar-apk.yml`: registra o commit efetivamente compilado e verifica manifesto do radar. A etapa de criar o ícone desnecessário foi removida.
- Nenhuma mudança nas telas, no radar, no Spotify, na versão do APK ou na chave configurada.

**Efeito visual limitado:** o ícone externo do app na lista de aplicativos pode passar a ser o ícone padrão do Android. A interface interna do launcher não muda. Posteriormente podemos restaurar um ícone customizado com um recurso confirmadamente incorporado ao GitHub.

## Atenção ao GitHub

O log enviado mostra **o workflow antigo** (`gradle --no-daemon --stacktrace :app:assembleDebug`), e não o comando do novo pacote (`--console=plain --warning-mode=summary`). Portanto o GitHub não está usando o workflow atualizado.

Faça upload dos **arquivos descompactados**, respeitando as pastas, no **mesmo branch em que o Actions está compilando**. Verifique em especial o arquivo `app/src/main/AndroidManifest.xml`. A linha `<application ...>` deve **não** conter `android:icon` nem `android:roundIcon`.

Se preferir a correção mínima, edite somente `app/src/main/AndroidManifest.xml` no próprio GitHub e remova as duas declarações de ícone. Essa correção ataca a falha observada mesmo sem trocar o workflow.

## Limitações da validação local

O XML e a estrutura do pacote foram verificados. Não há Android SDK/Gradle instalado neste ambiente para executar uma compilação Android completa, então outros erros posteriores à etapa de recursos ainda podem existir.

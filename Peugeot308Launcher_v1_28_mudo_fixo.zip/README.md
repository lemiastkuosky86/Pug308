Peugeot 308 Launcher v1.21

LEIA README-V1.21.md para a configuração do mini-card velocidade.

Peugeot 308 Launcher v1.19

LEIA README-V1.19.md para alterações, limites e testes.

# Peugeot Launcher 1.18 — pacote de testes para Jancar

Base: 1.16, **sem alterações na composição da tela principal, posição dos cartões e botões**.

## O que foi acrescentado
- **Configurações > Sistema > Diagnóstico para teste na Jancar**: ver e copiar relatório de estado do serviço IVI Car, GPS, clima, rede, som e versão. Não inclui localização precisa, endereços ou dados pessoais.
- **Menu do veículo > Escolher indicadores**: agora abre diretamente Configurações > Veículo, em vez de Aparência.
- `versionCode 118` e GitHub Actions preparado para assinatura original, com conferência de certificado antes de publicar.
- Mantido o diagnóstico OEM da versão anterior: sem transações Binder desconhecidas e sem envio de comandos CAN.

## Limitações que precisam de teste físico
- **CANBUS**: classe `JancarBridge` descobre e tenta vincular serviço do fabricante, mas ainda **não há leitura validada de telemetria** (combustível/RPM/autonomia). Não mostra valores fictícios.
- **Áudio OEM**: equalizador Android pode funcionar, mas balanço/fader/loudness e resposta do DSP da Jancar precisam de validação no carro. Valores salvos ou um serviço detectado não comprovam efeito sonoro.
- **Radar**: consulta OSM experimental; verifique cobertura e permissões; não é dispositivo de segurança nem substitui Waze/Radarbot. Não teste ao dirigir nem interaja com menus em movimento.
- **Spotify**: letras apenas por texto autorizado fornecido pelo usuário; sem sincronização automática.
- **Apps**: LED sinaliza último app aberto pelo launcher, não execução confirmada em segundo plano.

## Como atualizar pelo GitHub
Envie arquivos desta pasta para a **raiz** do repositório Pug308 preservando `.github/workflows` e `app/src`. Execute Actions. Confira verde e certificado SHA-256 original `531C7DF8FBCB6750AD96607D38179EFA62989575C57C20185895E9AE69D62752` e que `versionCode` é 117. Antes da instalação, mantenha uma cópia do APK atualmente funcional. Um build verde confirma compilação e assinatura, não funcionamento do CANBUS.

Veja `CHECKLIST-TESTE-CARRO.md` para testar tudo sem precisar voltar ao computador.

Consulte README-V1.18.md para CANBOX / OBD2 e pendências da integração de áudio.


Atualização v1.25: veja README-V1.25.md.

Atualização v1.26: veja README-V1.26.md.

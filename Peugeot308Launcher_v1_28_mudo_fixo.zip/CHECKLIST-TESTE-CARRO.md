# Checklist de teste no Peugeot 308 — v1.17

**Faça os testes com o veículo parado e em local seguro.** Não teste telas de configuração, equalização ou comandos ao dirigir. Evite usar volume elevado.

1. **Antes:** anote a versão instalada em Config. > Sistema. Instale o APK assinado por cima (não desinstale). Confirme `1.17` / código `117`.
2. **Visual (não alterado):** três painéis, tema chumbo-amarelo, botão Config., barra de favoritos, Spotify e relógio.
3. **Apps:** fixe YouTube, alterne ícone MIN/ORIG, abra-o, volte e confira o LED. Reinicie a central e confirme se favorito persistiu.
4. **Volume:** toque + e - em níveis individuais. Toque logo ACIMA dos botões: NÃO deve silenciar. Mudo deve escurecer; reativar deve fechar popup.
5. **Som:** equalizador ligado/desligado (comparação A/B em volume baixo); graves 0/10; loudness em 20% e 80%; balance L/R e fader F/R. Anote qual função é audível.
6. **Clima:** cidade fixa / GPS automático. Teste Atualizar agora e confira horário relativo; para troca automática de cidade é necessário GPS + internet.
7. **Spotify:** música, artista, capa, play/pause e letras cadastradas para uma música. Letras automáticas não estão disponíveis.
8. **Veículo:** marque 3 ou mais indicadores em Config. > Veículo, alterne páginas. Dados não disponíveis mostram `--`.
9. **CANBUS:** Config. > Veículo > Diagnóstico Jancar, observe IVI Car. Depois Sistema > Ver relatório > Copiar relatório. Um serviço encontrado não garante dados.
10. **Alertas:** execute APENAS os botões Testar radar / Testar velocidade com carro parado. Os alertas reais dependem de GPS, rede e cobertura OSM.
11. **Atualizações:** Config. > Sistema > Buscar atualização; GitHub Releases requer repositório público e Release com APK. Actions Artifacts por si só não é Release.
12. **Envio de resultado:** cole na conversa o relatório de diagnóstico e diga quais itens funcionaram. **Não envie keystore, senhas ou coordenadas precisas.**

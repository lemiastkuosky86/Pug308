**Versão atual: 1.42** — Spotify com três cards reorganizado e animação meteorológica leve. Veja README-V1.42.md.

**Versão atual: 1.41** — Spotify responsivo com faixa de reprodução para três cards. Veja README-V1.41.md.

# Peugeot 308 Launcher v1.40

Projeto Android Java para a multimídia Jancar RK3326.

- [O que mudou na versão 1.40](README-V1.40.md)
- [Histórico da versão 1.39](README-V1.39.md)
- [Checklist de validação no carro](CHECKLIST-V1.40.md)
- [Como compilar no GitHub Actions](INSTRUCOES-GITHUB.md)

**Importante:** projeto-fonte, não APK compilado. Use a mesma assinatura da versão
instalada, sem publicar senhas nem a chave no repositório.

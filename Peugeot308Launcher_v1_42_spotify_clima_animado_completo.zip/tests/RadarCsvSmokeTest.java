import com.peugeot308.oem.RadarStore;
import java.io.StringReader;
/** Teste sem Android: javac -d /tmp/test app/src/main/java/com/peugeot308/oem/RadarStore.java tests/RadarCsvSmokeTest.java && java -cp /tmp/test RadarCsvSmokeTest */
public final class RadarCsvSmokeTest {
    private static void expect(boolean ok, String label) {
        if (!ok) throw new AssertionError(label);
    }
    public static void main(String[] args) throws Exception {
        // Formato CSV sem cabeçalho, longitude/latitude/tipo (não é uma base real).
        String formatoMapa = "-46.550000,-23.120000,Radar Fixo - 50 kmh@50\n"
            + "-43.190000,-22.910000,Lombada - 0 kmh@0\n"
            + "-45.600000,-23.100000,Radar Móvel - 60 kmh@60\n"
            + "-45.601000,-23.101000,Pedágio\n";
        RadarStore.ParseResult a = RadarStore.parseCsv(new StringReader(formatoMapa), "maparadar.csv", 1000);
        expect(a.points.size() == 4, "linhas do MapaRadar");
        expect(a.points.get(0).type == RadarStore.FIXO && a.points.get(0).limit == 50, "radar fixo");
        expect(a.points.get(1).type == RadarStore.LOMBADA, "lombada");
        expect(a.points.get(2).type == RadarStore.MOVEL && a.points.get(2).limit == 60, "radar móvel");
        expect(a.points.get(3).type == RadarStore.PEDAGIO, "pedágio");
        expect(Math.abs(a.points.get(0).lat + 23.12) < 1e-6, "ordem de coordenadas");
        String cab = "latitude;longitude;tipo_de_radar;velocidade_leve\n"
            + "-23.1;-45.6;Radar Fixo;80\n-23.2;-45.7;Radar Móvel;60\n";
        RadarStore.ParseResult b = RadarStore.parseCsv(new StringReader(cab), "anttgps.csv", 1000);
        expect(b.points.size()==2 && b.points.get(0).limit==80, "CSV com cabeçalho");
        RadarStore store = new RadarStore();
        store.replaceImported(a.points);
        expect(store.personalCount()==4, "contagem dos pontos");
        expect(store.nearby(-23.12, -46.55, 1200, RadarStore.ALL).size()==1, "busca espacial");
        // Regressão: antigo filtro retangular aceitava candidatos ~1,6 km em busca de 1 km.
        expect(store.nearby(-23.130000, -46.537000, 1000, RadarStore.ALL).isEmpty(),
                "ponto fora do raio geodésico de 1 km");
        System.out.println("OK: CSV sem cabeçalho, CSV com cabeçalho, categorias, velocidade, coordenadas e busca local.");
    }
}

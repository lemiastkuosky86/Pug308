# Teste no carro — v1.38

**Sempre com o veículo estacionado.**

1. Verifique versão **1.38 (138)** e que a atualização instalou sobre a versão anterior (assinatura original configurada no Actions).
2. Home: confira botões volume `−`, `+`, MUDO centralizados e sem separador duplicado. Teste toque rápido em cada um.
3. Spotify: com **2 cards** e depois **3 cards**, reproduza música com título e artista longos; nada deve invadir o card do veículo, inclusive avançar/play/voltar.
4. Letras: abra faixa conhecida com LRC sincronizado; espere atualizar e veja a linha acompanhando a posição. Teste pausar/retomar e letra sem sincronização.
5. Apps: em `⋮`, renomeie e reorganize um aplicativo; feche e reabra o Apps, confira Home e reinicie a Jancar.
6. Aparência: verifique Preto/Chumbo à luz do dia, escolha uma cor, alterne tema **Escuro** e **Claro**, veja se ícones/textos e prévia combinam.
7. Brilho: selecione mínimo e automático, confirme rótulo 'solicitado'; toque rápido muda modo. **Segure 3 segundos sem soltar** para abrir o ajuste manual.
8. Rede → Testar controle USB / PS4: primeiro sem o controle, depois com cabo USB de dados. Se aparecer dispositivo de entrada HID, abra um emulador para confirmar os botões.
9. Verifique que Radar, Som/EQ, GPS e Wi-Fi continuam acessíveis; suas integrações com hardware não foram alteradas.

O teste em USB deve ser feito com cabo que transmita dados, e a porta da Jancar deve aceitar periféricos USB (host/OTG). Não recomenda mudanças aleatórias no firmware ou CANBOX.

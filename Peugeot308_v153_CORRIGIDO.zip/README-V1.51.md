# v1.51 — Tela de descanso e tonalidade

- Tela de descanso fullscreen com relogio e data, ativacao automatica apos 1–15 minutos (padrao 3), botao de teste e retorno por toque.
- Respeita o modo direcao e nao altera o volume, Spotify, Wi-Fi ou modo de espera da central.
- Ajustes independentes Graves (-6 a +6 dB), Agudos (-6 a +6 dB) e Reforco de graves (0 a 10) na aba Configuracoes > Som. Os ajustes complementam o EQ Android; nao sao garantia de controle do DSP/MCU Jancar.
- Mantidos os logs, GPS, card do veiculo e remocao de radar da v1.50.
- Compilar via workflow GitHub Actions com assinatura original para atualizar APK instalado.

# Peugeot 308 OEM Launcher v1.18 — integração CANBUS / OBD2 Bluetooth

Este pacote preserva a composição visual da versão 1.17. É **código-fonte**, não APK compilado.

## Implementado no código

- Fonte de dados selecionável em Configurações → Veículo: **Jancar/CANBOX** ou **OBD2 Bluetooth (ELM327)**.
- OBD2 Bluetooth clássico (SPP) para adaptadores já pareados, leitura dos PIDs padrão: 010C RPM, 010D velocidade, 0105 temperatura do motor, 012F nível de combustível, quando suportados. Não emite comandos de escrita nos módulos.
- Retém a fonte e endereço do adaptador. Conectar, desconectar e diagnóstico na aba Veículo.
- Sem dados recebidos, mostra `--`, sem fingir CAN conectado. O estado verde exige dado recente.
- No máximo **quatro indicadores** simultâneos, com aviso de limite. Migração das escolhas antigas.
- Quando o painel do carro está oculto, o botão `PC` fica no topo no espaço do atalho EQ; o EQ continua acessível pelas Configurações → Som.
- Botão MENU do veículo abre submenu local: configurar indicadores, mostrar/ocultar painel, abrir app original Jancar e selecionar fonte.
- Configurações reabrem na última aba utilizada.
- Os botões superiores + e - agora apenas abrem o popup; ajustes de um nível são feitos pelo próprio popup. Área de mudo reduzida à região correta.
- Botão LETRAS reposicionado junto ao cabeçalho do painel Spotify, disponível mesmo quando não há sessão ativa. As letras continuam **manuais**, não obtidas automaticamente do Spotify.
- Seleção individual de estilo minimalista/original dos favoritos também na aba Atalhos.
- Diagnóstico Jancar em janela rolável, texto reduzido no painel de áudio.
- Grave adicional limitado de maneira mais conservadora a até +3 dB nas bandas baixas (em vez de +5 dB também em médio-graves). **Teste auditivo necessário**.
- Acesso ao aplicativo original de áudio Jancar nas Configurações → Som.
- Mantido package `com.peugeot308.oem`, versionCode 118 e assinatura configurada por Secrets no workflow.

## Limitações importantes

- A leitura da telemetria **CANBOX/ICar** ainda depende de protocolo OEM e permissões Jancar não confirmados. Trocar a fonte para CANBOX não faz surgir RPM automaticamente.
- OBD2 exige adaptador físico Bluetooth clássico **ELM327 compatível e pareado**; alguns firmwares Jancar não permitem parear dispositivos Bluetooth genéricos. Wi-Fi ELM327 e BLE não são suportados nesta primeira implementação.
- Balanço, fader e loudness real do DSP/MCU Jancar não têm API autorizada confirmada; não afirmamos que os controles de visualização alterem o hardware. Use o aplicativo de EQ original para ajustes de fábrica.
- Os volumes de `AudioManager.STREAM_MUSIC` e da MCU da Jancar podem ser independentes. Não é seguro declarar volume único sem conhecer a API da MCU. Não foi implementada uma sincronização falsa.
- Letras de música não são obtidas automaticamente; precisam ser fornecidas pelo usuário com direito de uso.
- O novo código **não foi compilado nem validado na central** neste ambiente. Compile pelo GitHub Actions e confirme a etapa de verificação da assinatura digital antes de instalar.

## Compilação

Substitua os arquivos do projeto no repositório privado GitHub `Pug308`, mantendo a estrutura e os quatro Secrets de assinatura original. Execute `Actions → Compilar Peugeot 308 APK`, faça download de `Peugeot308Launcher-1.18-v118-assinatura-original`. O repositório privado não deve conter `debug.keystore`, senhas ou o Base64 da chave.

# Peugeot 308 Launcher v1.52 — Radar Pardal SP

Modificações isoladas em relação à v1.51. Preservadas as telas, configurações de áudio, multimídia, Android Auto e widgets existentes.

## Recursos
- Botão **Radar** adicionado ao lado do botão **Rede**, sem retirar os outros atalhos (capacidade passa a 5 opcionais + Config).
- Quatro opções: ligado inteligente (alerta sonoro somente acima do limite), somente visual, visual e áudio, desligado.
- Popup sobre a Home apenas com GPS atualizado, direção, movimento e radar detectado até 350 metros à frente; distância recalculada a cada fix (não são saltos estáticos).
- Bipes graduais pelo aproximar, com menor intervalo quando houver excesso de velocidade; nenhum excesso é considerado se o limite for desconhecido.
- Verificação da base SP por Wi-Fi a cada 24 horas, e ao reconectar, com retentativa após falha. ZIP de release Pardal, extração do `radares.csv`, conferência de formato e quantidade e troca com backup local. A atividade é assíncrona.
- Arquivo usado: https://github.com/Murkiriel/pardal/releases/latest/download/pardal-SP.zip

## Limitações / ensaios necessários
- A primeira execução precisa de Wi-Fi para baixar a base. Não há radares embutidos inicialmente.
- A checagem ocorre quando o processo está em execução; não há serviço persistente nem garantia de ocorrer enquanto a multimídia está desligada. Atualiza quando a central acorda e obtém Wi-Fi.
- Não há correspondência de rota/rua via mapa; filtro GPS por orientação reduz, mas não elimina alertas em pistas paralelas. Dados de direção podem estar ausentes. Radar de trecho é exibido apenas como ponto inicial, ainda sem velocidade média de trecho.
- O áudio usa o sistema Android de notificações; a central Jancar pode aplicar um volume distinto. Ajustar em testes reais, com carro estacionado inicialmente.
- O limite informado pelo Pardal pode estar ausente, desatualizado ou incorreto. A sinalização local prevalece.
- Fonte Pardal / OpenStreetMap. Dados sujeitos à ODbL 1.0; respeitar atribuição e requisitos de compartilhamento de bases derivadas.
- A validação da base usa cabeçalho/contagem e preservação do backup, mas **não realiza checagem SHA-256 do catálogo** nesta versão.
- Atualização do APK instalado exige a mesma chave de assinatura anterior (variáveis de ambiente PEUGEOT_KEYSTORE_* já existentes no projeto).

## Checklist na central
1. Compilar no GitHub Actions/Android Studio e instalar a versão 1.52 usando a assinatura original.
2. Conectar Wi-Fi e aguardar o status `Base SP` no menu Radar > Base de dados.
3. Conceder localização precisa e testar GPS em local aberto.
4. Selecionar cada modo e conferir silenciamento no modo visual e desligado.
5. Testar a mudança da distância e os sons perto de um ponto conhecido, observando sempre o trânsito e os limites sinalizados.
6. Reiniciar/acordar a central e verificar se a base local segue disponível offline.

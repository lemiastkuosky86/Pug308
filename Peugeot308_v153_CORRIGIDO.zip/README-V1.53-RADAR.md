# Peugeot 308 Launcher v1.53 — revisão do Radar Pardal SP

**Base de trabalho:** ZIP integral da versão 1.52 fornecida pelo usuário. Os demais componentes do launcher foram preservados.

## Correções e novos recursos

1. Corrigida a referência inválida à variável `l` no `onCreate` de `MainActivity` (trecho duplicado que impedia compilação).
2. Radar passa a contar com **serviço de localização em primeiro plano**, com notificação persistente enquanto ativado. O serviço é iniciado pela Activity com localização concedida e continua a receber GPS quando a Home fica em segundo plano, salvo restrição do firmware/sistema.
3. **Popup de sobreposição opcional** para Waze, Maps e outros aplicativos. Depende de permissão especial "Mostrar sobre outros apps"; se não concedida, o serviço pode continuar com áudio e notificação. Determinadas superfícies proprietárias do Android Auto/Jancar podem não aceitar sobreposições.
4. Mantidos os **quatro modos**: inteligente (som acima do limite), visual, visual e áudio, desligado. Em modo desligado o serviço é interrompido e a checagem diária automática não é executada.
5. **Simulação manual**: botão Radar > Ferramentas > Simular radar de 350 a 0 m. Dura cerca de 20 segundos; usa limite fictício de 60 km/h e velocidade simulada de 80 km/h, nunca substitui dados do GPS real; ao sair da Home cancela automaticamente.
6. **Filtro mais rigoroso** de direção, tolerância lateral e precisão GPS. Índice geográfico para processar apenas radares próximos em cada posição, em vez de varrer a lista toda. Ainda **não** é map matching: ruas paralelas, viadutos e marginais continuam exigindo atenção.
7. **Atualização manual** e data da última atualização no submenu Ferramentas. Download diário automático por Wi-Fi quando radar ligado (inclusive se serviço estiver ativo). Falha mantém a base anterior.
8. Download validado com **SHA-256** do CSV descompactado, conforme o catálogo `catalogo.json` da release Pardal. Quando validação falha, a base existente é preservada.
9. **Logs de radar** em `field-events.txt` somente quando o log de campo estiver habilitado: download, erros, radar selecionado (sem coordenadas), bipes, GPS (precisão e velocidade), simulação e mudanças de modo.
10. **Bipes graduais**: intervalos menores e volume moderadamente maior na aproximação em excesso de velocidade. Sem forçar o volume geral do sistema. Barra de progresso sutil no aviso da Home.

## Como testar na Jancar (com o carro parado primeiro)

1. Compilar o ZIP no GitHub Actions com a **mesma chave de assinatura** da instalação atual. O workflow falha se a assinatura configurada não corresponder à original.
2. Instalar o APK gerado; na Home, botão **Radar** > escolher um dos três modos ligados.
3. Autorizar a **localização precisa**. Em Android 13+, conceder notificação se solicitada.
4. Abrir **Radar > Ferramentas > Permitir avisos sobre outros aplicativos** e autorizar sobreposição, se desejar popup sobre Waze ou Maps.
5. Conectar Wi-Fi, abrir **Radar > Ferramentas > Atualizar radares agora**, aguardar, consultar Estado da base/GPS. A primeira instalação não contém base offline embutida.
6. Para testar sem sair da garagem, abrir **Radar > Ferramentas > Simular radar de 350 a 0 m**. Conferir contagem, popup e bipes; é uma simulação, não representa radar real.
7. Com local autorizado e base baixada, testar movimento real **sem manusear a tela enquanto dirige**. Se for possível, com passageiro, abrir um mapa e conferir se a notificação/overlay continuam ativos.
8. Ativar **Log de campo**, reproduzir o comportamento e exportar `.txt` para análise posterior.
9. Ao selecionar **Desligado**, conferir que notificação e popup do radar desaparecem.

## Limitações importantes

- **Não é um navegador por rotas**, portanto não identifica com certeza rua, pista ou viaduto. O filtro de rumo/precisão reduz falsos positivos, mas pode perder alertas em curvas ou GPS ruim. **A sinalização oficial prevalece**.
- Para **radar de trecho**, o ponto inicial e a classificação são reconhecidos, mas **não** é exibida uma velocidade média inventada. O cálculo confiável exige confirmar início, fim e percurso real por mapa/rota. A base Pardal traz os pontos inicial/final; não garante geometria detalhada do percurso nesse CSV.
- O serviço em primeiro plano depende de permissão de localização e pode ser limitado por versões/firmwares Android com gestão agressiva de energia.
- Quando a tela de outro app é proprietária e bloqueia camadas Android, o aviso de sobreposição pode não aparecer. O som pelo canal de notificação depende do roteamento de áudio configurado pela Jancar.
- O Pardal é uma base comunitária/aberta, sujeita a falhas e desatualizações. Fonte: https://github.com/Murkiriel/pardal — licença ODbL 1.0.
- **Sem compilação Android completa neste ambiente** (SDK/Gradle não instalados). Os testes de sintaxe Java, XML, regressão e geometria passaram; a etapa `assembleDebug` deve ser executada no GitHub Actions.

## Privacidade e desempenho

- O log não grava coordenadas, endereço, nomes de redes ou de músicas. Eventos de radar registram categorias, distância, precisão e velocidade.
- A base é consultada em RAM por um índice geográfico de células; o aplicativo não varre todos os radares a cada atualização GPS.
- Ativar o serviço de radar consome GPS e alguma bateria enquanto estiver ligado. No modo desligado, o serviço de radar não roda.

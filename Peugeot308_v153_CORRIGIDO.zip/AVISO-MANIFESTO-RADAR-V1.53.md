# Aviso de compilacao v1.53 — manifesto do radar

O APK `app-debug(20261114-191614).apk` tinha versao 1.53 e classes do radar,
mas seu **AndroidManifest compilado** ainda era o da v1.51. Faltavam o
`RadarForegroundService` e as permissoes de servico em primeiro plano,
sobreposicao e notificacao.

Este pacote reenvia **todo o projeto v1.53**, incluindo o manifesto correto,
e acrescenta uma etapa de validacao **apos compilar** no GitHub Actions.
Se faltar algum componente, o workflow falhara antes de publicar o APK.

Importante: substituir **todos** os arquivos do repositorio, incluindo
`app/src/main/AndroidManifest.xml` e `.github/workflows/compilar-apk.yml`.
Nao basta substituir apenas os arquivos `.java`.

A configuracao das permissoes no Android/Jancar continua necessaria.
O pacote foi verificado como ZIP e por analise estatica; a compilacao Android
completa e teste no dispositivo nao foram executados aqui.

# Peugeot 308 Launcher v1.33 — ajustes após teste no carro

**Base:** v1.32, mantendo os recursos anteriores e o layout principal.

## Correções solicitadas

1. **Volume e MUDO com mais distância:** reorganizados os três alvos superiores (`−`, `+`, MUDO) com espaços de 13 e 23 unidades, e divisor visível antes do MUDO. Reduz a chance de toque no botão vizinho sem deslocar os demais controles da Home.
2. **Aviso de velocidade ampliado:** agora dura **7 segundos** (4 s anteriores + 3 s), e a frase usa o limite configurado: **"VOCÊ ESTÁ ACIMA DE 50 km/h"** para um limite de 50, além de mostrar a velocidade atual. O título ajusta o tamanho para caber no aviso.
3. **Painel Radar mais transparente:** o submenu exibe em destaque a quantidade **real** de pontos pessoais carregados, a **data e hora da última importação**, o nome do arquivo e as quantidades por categoria. Mostra também a quantidade de pontos OSM consultados na área de até 7 km, **separadamente** da base offline, e um resumo do estado dos avisos. O diagnóstico inclui a causa mais provável de ausência de alerta (radar desativado, GPS inválido, categoria vazia, sem dados, etc.).
4. **Encerramento do alerta:** o quadro é redesenhado após o fim do prazo mesmo que o GPS pare de atualizar.

## Atenção — fonte de radares

A v1.33 **não vem com uma base nacional pré-carregada**: o contador inicia em zero até importar um CSV/ZIP compatível. A consulta online ao OpenStreetMap/Overpass oferece pontos conhecidos próximos, não uma base nacional garantida, e não é suficiente para todos os radares. A importação pessoal do MapaRadar não é automatizada nem redistribuída, respeitando o processo de obtenção do provedor. O aviso de **radar móvel** sinaliza apenas locais históricos/conhecidos na base, sem detectar a presença de fiscalização em tempo real.

O número exibido é efetivamente contabilizado no armazenamento do aparelho, não um exemplo fictício. Data e hora vêm do momento de importação; elas não significam que cada ponto esteja atualizado.

## Como testar no carro (estacionado)

- Instale por atualização com a assinatura original.
- Teste os botões `+`, `−` e MUDO, verificando a distância entre os alvos na tela.
- Em **Veículo → Velocidade**, defina um limite e modo visual; use o **teste de velocidade** em Configurações → Alertas, sem ultrapassar limites reais na via. Confira o título e os 7 s.
- Na Home, toque **Radar**. Veja "NENHUMA BASE OFFLINE IMPORTADA" caso não tenha carregado arquivo. Teste o alerta e consulte OSM parado com GPS e internet. Importe um CSV/ZIP pessoal compatível e confirme contador, categoria e data reais. Se não alertar na estrada, envie o relatório do diagnóstico — não é necessário dirigir acima do limite para testar a interface.

## Compilação

`versionCode 133`, `versionName 1.33`. Use o GitHub Actions existente e a chave de assinatura original.

**Validação:** parser RadarStore compilado e testado com CSV sintético, salvamento e recarga. A compilação Android completa não foi possível neste ambiente por ausência do Android SDK; requer Actions. A Jancar ainda precisa validar a funcionalidade real.

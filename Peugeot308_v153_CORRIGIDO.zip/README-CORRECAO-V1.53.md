# v1.53 — Correção do erro AAPT do ícone

Falha comprovada no log de 14/11/2026: `AndroidManifest.xml:19`: `resource mipmap/ic_launcher ... not found`.

Mudanças:
- Incluído `app/src/main/res/mipmap/ic_launcher.xml` sem qualifier, com a mesma arte e paleta do ícone adaptativo original.
- Preservado `mipmap-anydpi-v26/ic_launcher.xml` e seus drawables para Android 8.0+.
- Acrescentado passo no GitHub Actions **Garantir icone do aplicativo antes de compilar** para recompor automaticamente o fallback caso ele não exista no checkout, antes de o Gradle fazer o link dos recursos.
- Preservados `AndroidManifest.xml`, serviço do radar, permissões, assinatura esperada e versionCode 153.

Validação local: ZIP íntegro, XMLs parseáveis, referências verificadas, testes Java independentes compilados e executados. **O build Android completo não foi executado localmente** porque o ambiente não tem SDK/Gradle Android.

Envie os arquivos do projeto com a pasta `.github` inteira e `app/src/main/res/mipmap` para o repositório, execute o fluxo **APK assinado para Jancar** e confirme o passo de ícone antes da compilação.

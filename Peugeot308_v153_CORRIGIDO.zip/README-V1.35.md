# Peugeot 308 Launcher v1.35 — brilho rápido e leve

Base: v1.34. Pacote `com.peugeot308.oem`, `versionCode 135`, `versionName 1.35`.

## Novo mini-botão Brilho

- Em **Configurações → Aparência → Barra superior**, habilite **Mostrar Brilho (toque / segurar 3 s)**.
- A barra mantém o limite de **4 atalhos opcionais + Config**. Como a configuração anterior já podia ocupar os quatro, o botão Brilho **começa oculto para preservar os outros atalhos**. Desabilite um botão opcional antes de ativá-lo. O Equalizador mantém sua página completa.
- Ao habilitar, fica imediatamente após **Rede** na parte superior.
- Um **toque curto** alterna `Automático → Mínimo → Máximo → Automático`.
- **Segurar por 3 segundos** abre o menu completo com os quatro modos, controle manual de 5% a 100% e níveis mínimo/máximo configuráveis.
- Arrastar o controle seleciona modo **Manual**. O ícone muda com o modo.
- Todos os ajustes são salvos nas preferências e reaplicados ao retornar à Home ou após a tela despertar.
- O brilho automático usa nascer/pôr do sol da previsão quando disponíveis; caso contrário, a faixa horária local (6h–18h). Funciona mesmo que o usuário fixe a aparência em tema escuro.
- O ajuste da janela funciona sem permissões especiais. O brilho **de todo o Android** só muda se a Jancar permitir `WRITE_SETTINGS` e o firmware respeitar a configuração. Sem isso, a mudança pode ficar limitada ao launcher.
- Brilho mínimo nunca é zero para evitar tela inteiramente escura.

## Radar

- O botão **Radar** agora exibe um ponto discreto: cinza = desligado; amarelo = ainda faltam GPS ou dados; verde = GPS recente e pontos locais/online disponíveis.
- Verde **não** significa detecção ao vivo de fiscalização, nem garante cobertura da via. A importação pessoal e o diagnóstico da v1.34 seguem inalterados.

## Leveza e preservação

- Sem novos serviços residentes, bibliotecas externas, mapas ou tarefas em segundo plano.
- Spotify mantém as atualizações por evento da v1.34; a Home, volumes, MUDO, clima, radar, CAN/OBD e seus demais recursos foram preservados.
- O brilho só é reaplicado quando necessário (ou ao retornar/despertar a tela).

## Teste na Jancar

1. Compile pelo GitHub Actions, confirmando `1.35 / 135` e assinatura original.
2. Com carro estacionado, abra Aparência e desligue um atalho opcional se já houver quatro.
3. Habilite Brilho. Confira se o botão aparece ao lado de Rede.
4. Toque uma vez para Mínimo, novamente para Máximo e de novo para Automático. Confira os ícones.
5. Pressione e segure 3 segundos para abrir o ajuste manual. Experimente 20% e retorne a Automático.
6. Se o ajuste funcionar só dentro do launcher, confira a permissão especial de modificar configurações e a compatibilidade da MCU.
7. Abra Radar e verifique o ponto de status; compare com o diagnóstico real da base.

**Verificação:** revisão estática e checagem de arquivos. Este pacote é código-fonte completo, não APK assinado nem validado fisicamente. A compilação exige SDK/Gradle pelo GitHub Actions.

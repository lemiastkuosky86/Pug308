# Peugeot 308 Launcher v1.39 — revisão visual e de usabilidade

Base: v1.38 enviada para revisão. Preservados: Spotify, GPS, alertas, radar, clima,
CANBUS/OBD2, equalizador, volume gradual, MUDO vermelho e recursos anteriores.

## Correções desta versão

- **Temas:** 32 paletas passam pelo mesmo cálculo de cores da Home e das miniaturas. Cada
  miniatura agora usa a mesma cor de superfície e o mesmo destaque aplicado no aplicativo.
  Nas combinações claras, cores muito claras são escurecidas para manter legibilidade;
  nas escuras, destaques muito escuros recebem ajuste de contraste.
- **Modo automático:** Preto e Chumbo continuam escuros, salvo se o usuário escolher
  explicitamente o modo Claro. O brilho automático de dia/noite **não depende do tema**.
- **Configurações:** ao mudar tema com o menu aberto, fundo, título, subtítulo,
  separadores e botão Fechar atualizam suas cores imediatamente.
- **Menu Apps:** a janela de renomear/ordenar e a escolha do atalho personalizado
  usam as cores atuais do launcher, sem abrir a lista padrão do Android.
- **Spotify:** os botões de Anterior/Play/Próximo usam a largura real do card. Isso
  previne invasão do card do veículo quando há três painéis. O texto da música e do artista
  é limitado e recortado na área designada tanto na Home quanto no modo recolhido.
- **Volume:** áreas de toque equidistantes, um divisor em cada extremidade do grupo;
  volume normal e MUDO continuam com a lógica já aprovada.
- **Diagnóstico:** visual do relatório agora utiliza a paleta; inclui tema e modo atualmente usados.
- **Radar:** filtro de proximidade agora verifica distância geográfica real (metros) em vez de aceitar todos os pontos da caixa aproximada.
- **Regressões:** testes automatizados para 192 estados de paleta, 1368 geometrias de
  botões do Spotify, letras sincronizadas e leitor CSV de radar. Integrados ao GitHub Actions.

## Mantido da versão anterior

- Letras LRCLIB sincronizadas quando a faixa contém LRC com tempos.
- Renomeação e ordenação dos aplicativos, salvando preferências.
- Brilho com toque rápido (Auto/Mínimo/Máximo) e pressão de três segundos para menu Manual;
  valor mostrado é o brilho solicitado, que pode diferir do brilho físico da MCU Jancar.
- Diagnóstico de controles HID/PS4. Pareamento depende da pilha Bluetooth original da central.

## Limitações honestas

- **Não foi compilado com o Android SDK neste ambiente.** Compile com o GitHub Actions
  e valide o APK no carro parado antes de atualizar o uso diário.
- Correções de layout estão cobertas por testes matemáticos, não por captura de tela da
  Jancar. Ainda podem surgir questões de tamanho de fonte/driver na tela real.
- A API de volume da MCU Jancar, CANBUS completo e pareamento HID podem exigir suporte
  do firmware e não foram declarados resolvidos.
- Os diálogos nativos do sistema Android (permissões, Bluetooth, instalador) continuam
  com a aparência definida pela Jancar; a paleta do launcher não pode substituí-los.

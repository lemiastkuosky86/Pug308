# Peugeot 308 Launcher v1.48 — diagnóstico de campo

Base: v1.47. Sem alterações propositais no layout principal, nos três cards ou na assinatura.

## Registro de eventos

Abra **Configurações > Sistema e atualizações > LOG DE CAMPO** e ative **Registrar eventos de diagnóstico**.
Depois de utilizar o carro, escolha **Exportar log .txt** e salve o arquivo. O log privado possui limite próximo a 512 KB, com truncamento das partes mais antigas. Não registra título de música, SSID, senha, endereços nem coordenadas. Captura: início/retorno/pausa do launcher, tela ligada/desligada, mudanças Wi-Fi/rede/Bluetooth, estado da sessão de mídia, volume e rota Android, consumo de memória aproximado a cada 30 segundos.

**Limitação:** o registrador funciona somente enquanto o processo do app está ativo. O Android modificado da Jancar pode suspender ou encerrar o processo; não há serviço residente ou acesso aos logs de sistema. O estado de reprodução da sessão não prova que existe áudio audível no amplificador.

## Backup de configuração

Na mesma aba, **Salvar configuração** exporta JSON de preferências visuais e cards. **Restaurar configuração** abre o arquivo exportado e solicita confirmação. Reinicie o launcher para carregar a aparência restaurada. Não inclui endereço, histórico GPS, rede, músicas ou credenciais.

## Preservado

Wi-Fi automático sem abrir configurações; fade de volume padrão desligado; Spotify; temas; terceiro card do carro; clima e outras funcionalidades da v1.47. O app já consta como HOME no Manifest: se o firmware original insistir em abrir as configurações de Wi-Fi, é necessária verificação no sistema Jancar.

## Teste recomendado

1. Ativar o log antes do primeiro trajeto.
2. Desligar e ligar o carro, testar Wi-Fi e Spotify algumas vezes; quando houver silêncio, anotar o horário.
3. Exportar `.txt` e compartilhar no ChatGPT.
4. Desativar registro após os testes para poupar gravações.

## Validação

Arquivos e verificação estrutural conferidos; sem SDK Android completo neste ambiente, o APK não foi compilado nem testado em multimídia real. Compilar via GitHub Actions mantendo a chave de assinatura original.

# Peugeot 308 Launcher v1.45 — correções pontuais

Base: v1.44 corrigida (`quickDialog`), sem sistema de radares.

- Brilho: segurar o atalho por 750 ms abre o ajuste manual, em vez de 3 segundos; desbloqueado no modo direção.
- Perfis de brilho atualizados uma única vez na migração para 15% (mínimo/noite) e 80% (máximo/dia), com aplicação dos valores após atualização. Ajuste manual de 15% a 80%.
- Ajuste rápido do limite e tipo de aviso de velocidade não é bloqueado ao detectar velocidade GPS ou modo direção. Recomenda-se ajustar apenas quando for seguro ou por passageiro.
- Não foi alterado o leitor CANBUS nem adicionado estado de portas/porta-malas/travamento sem protocolo verificado.
- Mantido o workflow com assinatura original obrigatória e versão 1.45.

**Validação pendente:** compilação Android no GitHub Actions e testes na Jancar (gesto de pressionar e brilho real da tela).

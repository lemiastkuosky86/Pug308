# Peugeot 308 Launcher — v1.30 (130)

## Computador de bordo personalizável, sem histórico

Base: projeto completo v1.29. As telas de Clima, Spotify, Radar, EQ, volume, MUDO e as opções de CANBUS/OBD2 permanecem na base existente.

**Configurações → Veículo → Cards do computador de bordo**:

- Escolha **2 ou 3** indicadores no **card grande do veículo**.
- Configure separadamente o conteúdo de cada posição; escolhas são mantidas ao fechar/reabrir a central.
- Padrão da primeira instalação: **velocidade**, **km rodados (GPS, nesta sessão)** e **altitude (GPS)**.
- Outros indicadores GPS disponíveis: **velocidade média**, **velocidade máxima**, **bússola** e **precisão do sinal**.
- **Litros gastos (estimativa)** é opcional, calculado com a distância GPS e média manual de consumo em L/100 km. Não lê combustível do tanque e não é consumo instantâneo.
- Os dados OBD/CAN permanecem disponíveis como alternativas, mas mostram `--` se a central não fornecer valores válidos.
- Botão **Zerar quilômetros da sessão** reinicia distância, média, máxima e estimativa, com confirmação.
- Os mini-cards do topo continuam independentes e podem ser desligados individualmente como antes.

## GPS e limites

- O percurso é mantido **apenas na memória RAM**; nenhuma viagem é salva ao desligar/reiniciar a multimídia.
- São descartados pontos com precisão horizontal pior que 35 metros, saltos improváveis ou lacunas longas. Isso reduz erros de GPS, não garante medição perfeita.
- O tempo em movimento é usado internamente para calcular a média, mas **não existe card de tempo de viagem**.
- **Atenção:** nesta versão, o launcher deixa de pedir atualizações contínuas de localização ao ir para segundo plano, como já ocorria nas versões anteriores. Portanto, se abrir Waze/Spotify por cima, a distância pode não somar todo o trajeto. Para contagem contínua com outro app na frente será necessária uma implementação futura de serviço de localização em primeiro plano com notificação; não incluída nesta atualização.
- A altitude GPS é aproximada e pode oscilar. Nenhum indicador GPS é dado oficial da ECU.

## Arquivos alterados

- `app/src/main/java/com/peugeot308/oem/MainActivity.java`
- `app/build.gradle` (`versionCode 130`, `versionName 1.30`)
- `.github/workflows/compilar-apk.yml` (nome do artefato 1.30/130)
- `update.json`
- Documentação e checklist

## Instalação

Substitua os arquivos do repositório pelo conteúdo deste pacote, faça commit e acione GitHub Actions. O workflow exige os secrets da chave de assinatura original e verifica o SHA-256 do certificado antes de liberar o APK. Não remova esses controles.

## Situação dos testes

O ZIP foi conferido estruturalmente; **não foi compilado em Android SDK nem instalado na Jancar** neste ambiente. Verifique primeiro a compilação no GitHub Actions e teste com o carro parado.

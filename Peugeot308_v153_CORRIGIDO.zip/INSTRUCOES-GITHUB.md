# Compilação e instalação da v1.37

1. Substitua os arquivos do repositório privado `lemiastkuosky86/Pug308` pelos arquivos deste projeto. Preserve os secrets da assinatura original configurados no GitHub; não publique as senhas nem o keystore.
2. Confira `app/build.gradle`: `versionCode 137`, `versionName '1.37'`.
3. Faça commit/push e execute o workflow `.github/workflows/compilar-apk.yml`.
4. O workflow **verifica a assinatura** e só publica o artefato `Peugeot308Launcher-1.37-v137-assinatura-original` se a chave corresponder à assinatura aprovada.
5. Instale `app-debug.apk` do artefato aprovado. Não desinstale a versão anterior quando estiver usando o mesmo certificado.
6. Confira `CHECKLIST-V1.37.md` para os testes seguros com o carro parado.

Este pacote é projeto-fonte: **não contém APK pré-compilado**. A compilação real depende do Android SDK/Gradle do GitHub Actions, e o ajuste da tela inteira pode depender das permissões da Jancar.

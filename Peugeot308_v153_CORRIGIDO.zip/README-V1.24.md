# Peugeot 308 Launcher v1.24 — Layout com Spotify ampliado

Base: v1.23. Alteração exclusiva do layout da Home no modo recolhido após 10 segundos.

- Clima mantém **330 px** de largura (mesma largura do card normal) e estende sua altura para **592 px**.
- Sem card do veículo: Spotify ocupa **866 px** de largura, com **592 px** de altura.
- Com card do veículo: clima **330 px**, Spotify **516 px**, veículo **330 px**, todos com **592 px** de altura e espaçamento de **20 px**.
- O conteúdo do Spotify continua responsivo, com arte, faixa, controle de mídia e Letras no lugar.
- Não modifica barra superior, Radar, CANBUS, GPS, lógica dos botões ou configurações existentes.
- Versão Android 1.24 / versionCode 124.

**Validação:** verificar visualmente no aparelho, com veículo ligado e desligado e com o modo recolhido após 10 segundos. Compilação e execução real na central não foram realizadas neste ambiente.

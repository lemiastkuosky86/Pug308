# Checklist atual — Peugeot 308 Launcher v1.50

Teste com o veículo estacionado, sem modificar o firmware da central.

1. Após compilar no GitHub Actions e confirmar a assinatura, instale e confira versão **1.50 (150)**.
2. Abra a Home. Verifique temas, posicionamento de cards, clima animado e terceiro card do carro.
3. Confira **velocidade por GPS** e a configuração do limite; não há mais função de radar.
4. Ative `Configurações → Sistema → Registrar eventos de diagnóstico`.
5. Desligue e ligue o veículo, observe se abre na Home e se Wi-Fi reconecta sem abrir configurações.
6. Teste Spotify e música seguinte; se a barra avançar sem áudio, registre o horário e acione `Diagnosticar Spotify agora`.
7. Confira volume/mudo, brilho (15% a 80%), e opções do modo direção.
8. Se disponíveis, confira informações CANBUS/OBD2. Sinais ainda não identificados devem ficar como indisponíveis.
9. Exporte o log TXT depois do teste e envie para análise.

**Pendente de validação real:** serviços OEM da Jancar, Wi-Fi no retorno do standby e eventuais falhas de áudio.

# Peugeot 308 Launcher v1.36 — desempenho, Spotify e validação do radar

Base: v1.35, pacote `com.peugeot308.oem`, `versionCode 136`, `versionName 1.36`.

## O que mudou

1. **Redesenhos da Home**
   - O laço de manutenção continua verificando velocidade, radar, clima, conexões e mídia, mas **não invalida mais a tela inteira a cada segundo**.
   - Relógio e data são recalculados somente quando muda o minuto.
   - Com música tocando, apenas a região do progresso do Spotify recebe invalidação periódica; alterações reais de metadata, GPS, tema, rede, alertas e animações continuam redesenhando o necessário.
   - O brilho animado do logotipo recebe menos quadros (65 ms) para reduzir trabalho na RK3326.

2. **Primeira tela mais rápida**
   - A Home é instalada antes do início do serviço Jancar e dos efeitos do equalizador; os serviços são ativados com pequeno atraso para liberar o primeiro desenho.
   - A primeira consulta completa de sessões de mídia/rede ocorre depois do primeiro frame, sem remover monitoramento nem efeitos salvos.
   - O cache de ícones dos aplicativos não é apagado em toda volta para a Home; ainda pode ser limpo pelo menu de personalização de ícones.

3. **Cache privado da última música**
   - A última capa do Spotify é salva, quando disponível, em arquivo JPEG limitado a **320 × 320 px** no armazenamento **privado** do launcher, em uma única fila de gravação. Não há serviço persistente, download de imagens nem base remota extra.
   - Título e artista são lembrados. Sem sessão Spotify ativa, a interface informa **“Spotify • última música”** e **“Última música • aguardando conexão”**; **não apresenta essa prévia como reprodução atual**.
   - Assim que o Spotify transmite novos dados, eles substituem a prévia. A gravação só ocorre quando a música/capa muda.
   - Não é histórico de audição: somente a faixa mais recente, substituída pela próxima.

4. **Importação de dados de radar**
   - Mantido o leitor CSV de cabeçalhos ou sem cabeçalho (latitude/longitude/tipo/limite). ZIP aceita arquivos `.csv` e `.txt` quando seu conteúdo tem colunas compatíveis com CSV.
   - O teste `tests/RadarCsvSmokeTest.java` verifica listas semelhantes a exportações CSV de radar, além de categorias, limite, localização e índice espacial. É teste de formato **sintético**, não é uma exportação real do MapaRadar.
   - O aplicativo **não faz download automático do MapaRadar**, não contém sua base e preserva a importação pessoal pelo seletor de arquivos. Status, data e contagens são obtidos apenas da base realmente importada.

## Mantido da v1.35

- Submenu Radar e categorias (incluindo local conhecido de radar móvel); importação pessoal; OSM complementar; diagnóstico e teste.
- Wi-Fi automático opcional, menus rápidos, mini-cards/indicadores GPS, tema, brilho (toque curto e pressionar 3 s), equalizador independente e volume/MUDO.
- Spotify com controle via MediaSession, letras LRCLIB quando disponíveis, clima, atalhos e assinatura de atualização pelo GitHub Actions.

## Como compilar

1. Copie **todo o conteúdo do ZIP** para a raiz do repositório Pug308, preservando `.github/workflows/compilar-apk.yml` e `app/`.
2. Confira `app/build.gradle`: `versionCode 136`, `versionName '1.36'`.
3. Faça commit e push; o Actions gera o artefato `Peugeot308Launcher-1.36-v136-assinatura-original` se os segredos da chave estiverem configurados e o certificado esperado corresponder.
4. Não instale nenhum APK de assinatura diferente sobre a versão atual. Se o Actions falhar, envie o log.

## Teste no carro (estacionado para configurar)

1. Inicie a multimídia e observe se a Home aparece sem demora e sem telas vazias.
2. Inicie o Spotify, toque Próxima/Anterior, confira título, capa e controles.
3. Desligue e ligue a central: antes de a sessão reconectar, a última música pode aparecer marcada como **última**; depois deve atualizar para música atual.
4. Confira letras, equalizador, volume e MUDO; as interfaces de áudio da MCU ainda exigem teste real.
5. Escolha o **CSV (Planilha/Excel)** no site oficial MapaRadar, baixe pela sua conta e importe em **Radar → Importar CSV/ZIP**. Confira se as categorias e a contagem são plausíveis. Se disser “nenhum ponto reconhecido”, envie o arquivo original para estudarmos o formato.
6. Use **Radar → Diagnóstico / Testar aviso** antes de confiar nos alertas na estrada. GPS e pontos cadastrados não garantem cobertura de todos os radares; pontos móveis não representam detecção ao vivo.
7. Confira mini-cards, limite de velocidade, clima, retorno dos atalhos e animações.

**Limitações:** projeto-fonte revisado e teste puro Java da importação executado; ainda não compilado com Android SDK neste ambiente e não testado na Jancar. O formato exato do CSV fornecido ao usuário pelo MapaRadar ainda não foi analisado.

# Peugeot 308 Launcher v1.37 — estabilidade

Base: v1.36. **Sem mudança de layout.** `versionCode 137`, `versionName 1.37`.

- **OBD2 reconecta sozinho:** o leitor tenta de novo quando o adaptador não está pronto na ignição ou a conexão cai, e passa a ler também a temperatura externa. Mesma interface de antes (`start`, `stop`, `isLive`).
- **Volume:** se a Activity for destruída durante o fade de entrada ou o mudo, a rampa é concluída (antes podia ficar em 0).
- **Manifest:** `configChanges` (a tela não é mais recriada por mudança de tema, densidade ou idioma da central), `BLUETOOTH_ADMIN` (permite cancelar a busca Bluetooth antes de conectar ao OBD2) e ícone próprio do app.
- **Nomes dos apps:** cache dos rótulos (menos consultas ao sistema ao desenhar o dock).
- **Atualização:** se a consulta falhar, a próxima tentativa automática só ocorre em cerca de 1 hora.
- **Clima:** sem código de tempo mostra `--` (antes "Poucas nuvens").
- **GitHub Actions:** os segredos da assinatura ficam só nos dois steps que os usam.
- **Testes:** pasta `ferramentas-teste` de volta (ObdTest e EngineTest). Veja o `LEIA-ME.md` dela.

Teste físico pendente. Compilar via GitHub Actions.

# Verificação da v1.36

- [ ] GitHub Actions terminou com sucesso e assinatura SHA-256 original foi validada.
- [ ] APK reconhecido pelo Android como `1.36 / 136` e pode atualizar `com.peugeot308.oem`.
- [ ] Home aparece rapidamente ao ligar e segue funcionando depois da suspensão.
- [ ] Spotify troca faixas e atualiza a capa quando chegam eventos da sessão.
- [ ] Se a sessão não estiver pronta, a última música aparece identificada como prévia, não como tocando.
- [ ] Nenhuma imagem de capa anterior aparece associada incorretamente à música atual.
- [ ] Barra de reprodução atualiza; botão Letras, áudio e MUDO permanecem corretos.
- [ ] Barra de brilho mantém toque curto e segurar 3 s.
- [ ] Radar abre submenu e aceita CSV/ZIP. Conferir quantidade real e última importação.
- [ ] Teste sonoro e visual do radar funciona parado; alertas de estrada só após validação de base e GPS.
- [ ] Clima, Wi-Fi e mini-cards continuam como na 1.35.

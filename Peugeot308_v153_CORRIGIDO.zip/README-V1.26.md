# Peugeot 308 Launcher v1.26 — volume direto no topo

- Três ícones sem números no topo: `−`, `+`, alto-falante/mudo.
- `−` e `+` alteram diretamente o volume de mídia Android, sem abrir menu.
- Mudo alterna volume zero e restaura gradualmente o nível anterior.
- Novo indicador central discreto, número e barra de nível; desaparece após 2 segundos, mesmo no mudo.
- Indicador não é modal nem bloqueia toques nos controles da tela.
- Mantidos os demais componentes e aparência da v1.25.

**Limite conhecido:** Jancar pode ter volume MCU independente do volume de mídia Android. Não é sincronizado.

**Teste:** instalar com a mesma assinatura da instalação original; testar + e − em sequência rápida, mudo/restaurar, Spotify tocando, fechamento após 2s, e controles OEM.

**Compilação:** não foi efetuada neste ambiente. Usar o workflow do GitHub Actions.

package android.os;
import java.util.*;
public class Handler {
  public static final List<Runnable> queue = Collections.synchronizedList(new ArrayList<>());
  public Handler(Looper l) {}
  public boolean post(Runnable r) { r.run(); return true; }              // roda na hora
  public boolean postDelayed(Runnable r, long ms) { queue.add(r); return true; } // guarda; o teste decide quando rodar
  public void removeCallbacks(Runnable r) { queue.remove(r); }
  public void removeCallbacksAndMessages(Object o) { queue.clear(); }
  public static int drain(int max) { int n = 0; while (!queue.isEmpty() && n < max) { Runnable r = queue.remove(0); r.run(); n++; } return n; }
}

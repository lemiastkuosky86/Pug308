package android.media;
public class AudioManager {
  public static final int STREAM_MUSIC = 3;
  public int vol = 10, max = 30; public boolean ignoreSet = false; public int sets = 0;
  public int getStreamVolume(int s) { return vol; }
  public int getStreamMaxVolume(int s) { return max; }
  public void setStreamVolume(int s, int v, int f) { sets++; if (!ignoreSet) vol = Math.max(0, Math.min(max, v)); }
}

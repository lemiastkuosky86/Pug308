package android.media.audiofx;
public class Equalizer extends AudioEffect {
  public static boolean fail = false; public static Equalizer last;
  public short[] levels = new short[5]; public boolean enabled;
  public Equalizer(int p, int s) { if (fail) throw new RuntimeException("sem efeito"); last = this; }
  public short getNumberOfBands() { return 5; }
  public short[] getBandLevelRange() { return new short[]{-1500, 1500}; }
  public int getCenterFreq(short b) { return new int[]{60000, 230000, 910000, 3600000, 14000000}[b]; }
  public int[] getBandFreqRange(short b) { int[][] r = {{0,120000},{120000,500000},{500000,2000000},{2000000,7000000},{7000000,20000000}}; return r[b]; }
  public void setBandLevel(short b, short l) { levels[b] = l; }
  public void setEnabled(boolean e) { enabled = e; }
  public boolean getEnabled() { return enabled; }
  public void release() {}
}

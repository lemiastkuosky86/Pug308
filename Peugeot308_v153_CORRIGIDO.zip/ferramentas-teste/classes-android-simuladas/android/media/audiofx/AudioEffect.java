package android.media.audiofx;
public class AudioEffect { public static final String EXTRA_AUDIO_SESSION = "s", ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION = "o", ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION = "c"; }

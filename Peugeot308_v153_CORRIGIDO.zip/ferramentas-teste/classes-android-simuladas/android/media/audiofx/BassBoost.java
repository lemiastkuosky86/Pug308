package android.media.audiofx;
public class BassBoost extends AudioEffect { public BassBoost(int p, int s) {} public boolean getStrengthSupported() { return true; } public void setStrength(short s) {} public void setEnabled(boolean e) {} public void release() {} }

package android.content;
public interface SharedPreferences {
  boolean getBoolean(String k, boolean d); String getString(String k, String d); float getFloat(String k, float d); int getInt(String k, int d);
  Editor edit();
  interface Editor { Editor putBoolean(String k, boolean v); Editor putString(String k, String v); Editor putFloat(String k, float v); Editor putInt(String k, int v); void apply(); }
}

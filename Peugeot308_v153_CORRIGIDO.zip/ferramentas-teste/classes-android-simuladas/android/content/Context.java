package android.content;
public abstract class Context {
  public static final String AUDIO_SERVICE = "audio";
  public abstract Object getSystemService(String n);
  public abstract SharedPreferences getSharedPreferences(String n, int m);
  public Context getApplicationContext() { return this; }
  public Intent registerReceiver(BroadcastReceiver r, IntentFilter f) { return null; }
  public void sendBroadcast(Intent i) {}
}

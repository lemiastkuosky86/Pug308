package com.peugeot308.oem;
import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.*;

public class ObdTest {
  /** Simulador de adaptador ELM327 com ECU. */
  static class Elm {
    final PipedOutputStream toApp = new PipedOutputStream(); final PipedInputStream fromElm;
    final PipedOutputStream toElm = new PipedOutputStream(); final PipedInputStream fromApp;
    volatile boolean closed; long dieAfterMs = -1; final long born = System.currentTimeMillis();
    volatile boolean ecuOn = true; volatile int reads = 0;
    Elm() throws IOException { fromElm = new PipedInputStream(toApp, 4096); fromApp = new PipedInputStream(toElm, 4096);
      Thread t = new Thread(this::run); t.setDaemon(true); t.start(); }
    void say(String s) throws IOException { toApp.write(s.getBytes("US-ASCII")); toApp.flush(); }
    void run() {
      try {
        StringBuilder cmd = new StringBuilder(); int b;
        while (!closed && (b = fromApp.read()) >= 0) {
          if (dieAfterMs >= 0 && System.currentTimeMillis() - born > dieAfterMs) { toApp.close(); return; }
          if (b != '\r') { cmd.append((char) b); continue; }
          String c = cmd.toString().trim(); cmd.setLength(0);
          if (c.startsWith("AT")) { say("OK\r\r>"); continue; }
          if (!ecuOn) { say("UNABLE TO CONNECT\r\r>"); continue; }
          reads++;
          switch (c) {
            case "0100": Thread.sleep(300); say("SEARCHING...\r41 00 BE 3F A8 13\r\r>"); break;
            case "010C": say("41 0C 1A F8\r\r>"); break;
            case "010D": say("41 0D 3C\r\r>"); break;
            case "0105": say("41 05 73\r\r>"); break;
            case "012F": say("41 2F 80\r\r>"); break;
            case "0146": say("41 46 46\r\r>"); break;
            default: say("NO DATA\r\r>");
          }
        }
      } catch (Exception e) { }
    }
    ObdBluetoothReader.Link link() { return new ObdBluetoothReader.Link() {
      public InputStream in() { return fromElm; } public OutputStream out() { return toElm; }
      public void close() { closed = true; try { toApp.close(); } catch (Exception e) {} try { toElm.close(); } catch (Exception e) {} } }; }
  }

  static int fails = 0;
  static void check(String name, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + name); if (!ok) fails++; }
  static void waitFor(java.util.function.BooleanSupplier c, long ms) throws Exception { long u = System.currentTimeMillis() + ms; while (!c.getAsBoolean() && System.currentTimeMillis() < u) Thread.sleep(25); }

  public static void main(String[] a) throws Exception {
    // T1: leitura normal
    {
      List<String[]> got = Collections.synchronizedList(new ArrayList<>()); List<String> st = Collections.synchronizedList(new ArrayList<>());
      AtomicInteger opens = new AtomicInteger();
      ObdBluetoothReader r = new ObdBluetoothReader((v, live, s) -> { st.add(s); if (live) got.add(v); }) {
        @Override Link openLink(String ad) throws IOException { opens.incrementAndGet(); return new Elm().link(); } };
      r.start("AA:BB");
      waitFor(() -> got.size() >= 2, 6000);
      String[] v = got.isEmpty() ? null : got.get(got.size() - 1);
      check("T1 conectou e leu dados", v != null);
      if (v != null) {
        check("T1 rpm 0x1AF8/4 = 1726", "1726".equals(v[ObdBluetoothReader.V_RPM]));
        check("T1 velocidade 60", "60".equals(v[ObdBluetoothReader.V_SPEED]));
        check("T1 motor 75 C", "75".equals(v[ObdBluetoothReader.V_COOLANT]));
        check("T1 combustível 50%", "50".equals(v[ObdBluetoothReader.V_FUEL]));
        check("T1 externa 30 C", "30".equals(v[ObdBluetoothReader.V_AMBIENT]));
      }
      check("T1 isLive", r.isLive());
      r.stop(); int n = got.size(); Thread.sleep(500);
      check("T1 após stop() não chegam mais dados", got.size() == n && !r.isLive());
    }
    // T2: start repetido (corrida entre sessão velha e nova)
    {
      List<String[]> got = Collections.synchronizedList(new ArrayList<>()); AtomicInteger opens = new AtomicInteger();
      ObdBluetoothReader r = new ObdBluetoothReader((v, live, s) -> { if (live) got.add(v); }) {
        @Override Link openLink(String ad) throws IOException { opens.incrementAndGet(); try { Thread.sleep(40); } catch (Exception e) {} return new Elm().link(); } };
      for (int i = 0; i < 12; i++) { r.start("AA:BB"); Thread.sleep(i % 3 == 0 ? 5 : 60); }
      waitFor(() -> got.size() >= 3, 6000);
      check("T2 depois de 12 start() seguidos a última sessão está viva", r.isLive() && got.size() >= 3);
      r.stop();
    }
    // T3: o adaptador cai e volta
    {
      List<String> st = Collections.synchronizedList(new ArrayList<>()); AtomicInteger opens = new AtomicInteger(); AtomicInteger lives = new AtomicInteger();
      ObdBluetoothReader r = new ObdBluetoothReader((v, live, s) -> { st.add(s); if (live) lives.incrementAndGet(); }) {
        @Override Link openLink(String ad) throws IOException { int n = opens.incrementAndGet(); Elm e = new Elm(); if (n == 1) e.dieAfterMs = 1500; return e.link(); } };
      r.retryMs = 400; r.start("AA:BB");
      waitFor(() -> opens.get() >= 2 && lives.get() > 0 && r.isLive() && opens.get() >= 2, 12000);
      long t0 = System.currentTimeMillis(); waitFor(() -> opens.get() >= 2 && r.isLive(), 12000);
      check("T3 reconectou sozinho após a queda (aberturas=" + opens.get() + ")", opens.get() >= 2 && r.isLive());
      check("T3 mostrou mensagem de nova tentativa", st.stream().anyMatch(s -> s.contains("nova tentativa")));
      r.stop();
    }
    // T4: Bluetooth desligado nas primeiras tentativas (carro acabou de ligar)
    {
      AtomicInteger opens = new AtomicInteger(); List<String> st = Collections.synchronizedList(new ArrayList<>());
      ObdBluetoothReader r = new ObdBluetoothReader((v, live, s) -> st.add(s)) {
        @Override Link openLink(String ad) throws IOException { if (opens.incrementAndGet() <= 2) throw new IOException("Bluetooth desligado"); return new Elm().link(); } };
      r.retryMs = 300; r.start("AA:BB");
      waitFor(r::isLive, 8000);
      check("T4 conectou depois de 2 falhas", r.isLive() && opens.get() == 3);
      check("T4 estado informou Bluetooth desligado", st.stream().anyMatch(s -> s.contains("Bluetooth desligado")));
      r.stop();
    }
    // T5: ignição desligada (ECU muda) e depois liga: não deve ficar 'live' sem dados e deve voltar sozinho
    {
      Elm[] holder = new Elm[1]; List<String> st = Collections.synchronizedList(new ArrayList<>());
      ObdBluetoothReader r = new ObdBluetoothReader((v, live, s) -> st.add(s)) {
        @Override Link openLink(String ad) throws IOException { holder[0] = new Elm(); holder[0].ecuOn = false; return holder[0].link(); } };
      r.start("AA:BB");
      Thread.sleep(2500);
      check("T5 com ECU muda não declara dados", !r.isLive());
      check("T5 mostra aguardando ECU", st.stream().anyMatch(s -> s.contains("aguardando a ECU")));
      holder[0].ecuOn = true;
      waitFor(r::isLive, 9000);
      check("T5 volta a ler quando a ignição liga", r.isLive());
      r.stop();
    }
    System.out.println(fails == 0 ? "TUDO OK" : ("FALHAS: " + fails));
    System.exit(fails == 0 ? 0 : 1);
  }
}

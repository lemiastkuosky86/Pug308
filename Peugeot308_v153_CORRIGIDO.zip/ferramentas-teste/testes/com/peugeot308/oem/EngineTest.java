package com.peugeot308.oem;
import android.content.*;
import android.media.AudioManager;
import android.media.audiofx.Equalizer;
import android.os.*;
import java.lang.reflect.*;
import java.util.*;

public class EngineTest {
  static int fails = 0;
  static void check(String n, boolean ok) { System.out.println((ok ? "PASS " : "FAIL ") + n); if (!ok) fails++; }
  static class SP implements SharedPreferences {
    final Map<String,Object> m; SP(Map<String,Object> m) { this.m = m; }
    public boolean getBoolean(String k, boolean d) { Object o = m.get(k); return o == null ? d : (Boolean) o; }
    public String getString(String k, String d) { Object o = m.get(k); return o == null ? d : (String) o; }
    public float getFloat(String k, float d) { Object o = m.get(k); return o == null ? d : (Float) o; }
    public int getInt(String k, int d) { Object o = m.get(k); return o == null ? d : (Integer) o; }
    public Editor edit() { return new Editor() {
      public Editor putBoolean(String k, boolean v) { m.put(k, v); return this; } public Editor putString(String k, String v) { m.put(k, v); return this; }
      public Editor putFloat(String k, float v) { m.put(k, v); return this; } public Editor putInt(String k, int v) { m.put(k, v); return this; } public void apply() {} }; }
  }
  static class Ctx extends Context {
    final AudioManager am = new AudioManager(); final Map<String,Object> store;
    Ctx(Map<String,Object> s) { store = s; }
    public Object getSystemService(String n) { return am; }
    public SharedPreferences getSharedPreferences(String n, int m) { return new SP(store); }
  }
  static SoundEngine mk(Ctx c) throws Exception { Constructor<SoundEngine> k = SoundEngine.class.getDeclaredConstructor(Context.class); k.setAccessible(true); return k.newInstance(c); }
  static void step(SoundEngine e) throws Exception { Method m = SoundEngine.class.getDeclaredMethod("autoVolumeStep"); m.setAccessible(true); m.invoke(e); }
  static void drain() { Handler.drain(2000); }
  static int maxLevel(short[] l) { int m = Integer.MIN_VALUE; for (short s : l) m = Math.max(m, s); return m; }
  static int minLevel(short[] l) { int m = Integer.MAX_VALUE; for (short s : l) m = Math.min(m, s); return m; }

  public static void main(String[] a) throws Exception {
    // E1/E2: loudness dinâmico e suavidade
    {
      Ctx c = new Ctx(new HashMap<>()); SoundEngine e = mk(c); e.applyNow();
      Equalizer q = Equalizer.last; check("E0 efeito global criado e ativo", e.effectOk && q.enabled && e.nBands == 5);
      c.am.vol = 5; e.volumeChanged();           // volume baixo (17%)
      short[] prev = q.levels.clone(); int maxJump = 0;
      while (!Handler.queue.isEmpty()) { Handler.drain(1); for (int i = 0; i < 5; i++) maxJump = Math.max(maxJump, Math.abs(q.levels[i] - prev[i])); prev = q.levels.clone(); }
      check("E1 volume baixo reforça agudos (banda 14k=" + q.levels[4] + " mB) e graves (" + q.levels[0] + " mB)", q.levels[4] > 150 && q.levels[0] > 50);
      check("E2 transição suave: maior salto por passo = " + maxJump + " mB (<= 40)", maxJump <= 40);
      c.am.vol = 20; e.volumeChanged(); drain();  // volume alto (67%)
      check("E3 volume alto: curva plana (todas as bandas = 0)", maxLevel(q.levels) == 0 && minLevel(q.levels) == 0);
      e.setLoudOn(false); c.am.vol = 3; e.volumeChanged(); drain();
      check("E4 loudness desligado: sem reforço em volume baixo", maxLevel(q.levels) == 0);
    }
    // E5: limites do efeito
    {
      Ctx c = new Ctx(new HashMap<>()); SoundEngine e = mk(c); e.setLoudOn(false);
      java.util.Arrays.fill(e.band, 12f); e.pre = 12f; e.applyNow();
      check("E5 nunca passa do limite do aparelho (+15 dB)", maxLevel(Equalizer.last.levels) <= 1500);
      java.util.Arrays.fill(e.band, -12f); e.pre = -12f; e.applyNow();
      check("E6 nunca passa do limite mínimo (-15 dB)", minLevel(Equalizer.last.levels) >= -1500);
    }
    // E7: volume automático
    {
      Ctx c = new Ctx(new HashMap<>()); SoundEngine e = mk(c); c.am.vol = 10; e.autoVolOn = true; e.autoVolMax = 3;
      step(e); check("E7 parado: nada muda", c.am.vol == 10 && e.autoOffset == 0);
      e.speedKmh = 120; int ticks = 0; List<Integer> vols = new ArrayList<>();
      for (int i = 0; i < 20; i++) { step(e); vols.add(c.am.vol); }
      check("E8 a 120 km/h sobe 1 nível por vez até +3 (volumes=" + vols.subList(0, 8) + "...)", c.am.vol == 13 && e.autoOffset == 3);
      boolean gradual = true; for (int i = 1; i < vols.size(); i++) if (Math.abs(vols.get(i) - vols.get(i - 1)) > 1) gradual = false;
      check("E9 nunca salta mais de 1 nível", gradual);
      e.speedKmh = 0; for (int i = 0; i < 20; i++) step(e);
      check("E10 ao parar volta exatamente ao volume original (10)", c.am.vol == 10 && e.autoOffset == 0);
      // usuário mexe durante o aumento
      e.speedKmh = 120; for (int i = 0; i < 6; i++) step(e);      // sobe um pouco
      int mid = c.am.vol; c.am.vol = mid + 3;                      // usuário sobe +3
      e.speedKmh = 0; for (int i = 0; i < 20; i++) step(e);
      check("E11 volume mexido pelo usuário vira a nova referência (esperado " + (10 + 3) + ", ficou " + c.am.vol + ")", c.am.vol == 13);
    }
    // E12: central ignora o ajuste de volume
    {
      Ctx c = new Ctx(new HashMap<>()); SoundEngine e = mk(c); c.am.vol = 10; c.am.ignoreSet = true; e.autoVolOn = true; e.speedKmh = 120;
      for (int i = 0; i < 40; i++) step(e);
      check("E12 volume ignorado pela central: desiste (blocked=" + e.autoBlocked + ") e não deriva (offset=" + e.autoOffset + ")", e.autoBlocked && e.autoOffset == 0 && c.am.vol == 10);
      c.am.ignoreSet = false; e.speedKmh = 0; for (int i = 0; i < 10; i++) step(e);
      check("E13 sem mexer no volume do usuário depois de desistir", c.am.vol == 10);
    }
    // E14: mudo e fade
    {
      Ctx c = new Ctx(new HashMap<>()); SoundEngine e = mk(c); c.am.vol = 0; e.autoVolOn = true; e.speedKmh = 120;
      for (int i = 0; i < 10; i++) step(e); check("E14 mudo: não acorda o som", c.am.vol == 0);
      c.am.vol = 10; e.volumeBusy = true; for (int i = 0; i < 10; i++) step(e); check("E15 durante fade/rampa: não mexe", c.am.vol == 10 && e.autoOffset == 0);
    }
    // E16: sem efeito do Android
    {
      Equalizer.fail = true; Ctx c = new Ctx(new HashMap<>()); SoundEngine e = mk(c);
      try { e.applyNow(); e.volumeChanged(); drain(); check("E16 sem efeito: não quebra e avisa (" + e.status + ")", !e.effectOk && e.status.contains("indisponível")); }
      catch (Throwable t) { check("E16 sem efeito: não quebra (" + t + ")", false); }
      Equalizer.fail = false; SystemClock.offset += 25000; e.applyNow();
      check("E17 depois de 20 s tenta de novo e recupera", e.effectOk);
    }
    // E18: persistência
    {
      Map<String,Object> store = new HashMap<>(); Ctx c = new Ctx(store); SoundEngine e = mk(c);
      e.setBand(3, 4.5f); e.setPre(-3f); e.saveCustom("Meu rock!"); e.setLoudAmt(.8f); e.setAutoVolMax(5); e.saveNow();
      SoundEngine e2 = mk(new Ctx(store));
      check("E18 curva, pré e predefinição própria voltam depois de 'desligar o carro'", e2.band[3] == 4.5f && e2.pre == -3f && e2.customNames.contains("Meu rock!") && e2.presetName.equals("Meu rock!") && Math.abs(e2.loudAmt - .8f) < 1e-6 && e2.autoVolMax == 5);
      e2.applyPreset("Plano"); e2.applyPreset("Meu rock!");
      check("E19 aplicar predefinição própria restaura a curva", e2.band[3] == 4.5f && e2.pre == -3f);
      e2.deleteCustom("Meu rock!"); check("E20 apagar predefinição própria", !e2.customNames.contains("Meu rock!"));
    }
    System.out.println(fails == 0 ? "TUDO OK" : ("FALHAS: " + fails)); System.exit(fails == 0 ? 0 : 1);
  }
}

# Testes fora do Android (opcional)
Testam o leitor OBD2 (contra um ELM327 simulado) e o motor de som, usando classes do Android simuladas.
Precisa de JDK 17+ e de um `android.jar` (API 35). Não faz parte do build do APK.

    F="classes-android-simuladas/android/os/*.java classes-android-simuladas/android/content/*.java classes-android-simuladas/android/media/*.java classes-android-simuladas/android/media/audiofx/*.java"
    S=../app/src/main/java/com/peugeot308/oem
    javac -encoding UTF-8 -cp classes-android-simuladas:android.jar -d out $F $S/ObdBluetoothReader.java testes/com/peugeot308/oem/ObdTest.java && java -cp out:android.jar com.peugeot308.oem.ObdTest
    javac -encoding UTF-8 -cp classes-android-simuladas:android.jar -d out2 $F $S/EqMath.java $S/SoundEngine.java testes/com/peugeot308/oem/EngineTest.java && java -cp out2:android.jar com.peugeot308.oem.EngineTest

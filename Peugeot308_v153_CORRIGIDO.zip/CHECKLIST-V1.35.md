# Checklist de teste v1.35 (Peugeot 308 / Jancar RK3326)

Faça os ajustes apenas com o veículo parado.

- [ ] Confirmar APK `1.35` / `135` e assinatura original antes de instalar.
- [ ] Abrir Configurações > Aparência e localizar "Mostrar Brilho".
- [ ] Se quatro atalhos já estiverem visíveis, ocultar um opcional (não precisa ser o EQ) e ativar "Mostrar Brilho".
- [ ] Com brilho no topo, toque curto: Automático → Mínimo → Máximo → Automático.
- [ ] Pressionar por 3 s: abrir menu Brilho sem executar o toque curto extra.
- [ ] Arrastar controle manual; a tela não pode ficar totalmente preta.
- [ ] Ajustar valores mínimo e máximo, salvar; verificar após fechar e reabrir o launcher.
- [ ] Testar brilho Auto durante dia e noite, inclusive com tema escuro fixo.
- [ ] Testar estado do botão Radar: cinza desligado, amarelo sem condições completas, verde com base + GPS.
- [ ] Testar se Radar/Spotify/Clima/EQ/Volume/MUDO/Veículo mantêm comportamento anterior.
- [ ] Se brilho geral da central não mudar, verificar WRITE_SETTINGS e comportamento do firmware Jancar.

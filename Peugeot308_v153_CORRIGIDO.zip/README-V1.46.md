# Peugeot 308 Launcher v1.46 — terceiro card do veículo

- Base: v1.45 (brilho e ajuste de velocidade preservados).
- Computador de bordo: somente o terceiro card pode exibir uma silhueta superior do Peugeot 308, sem criar um quarto card.
- Modos: indicador anterior, carro com todas as informações, apenas desenho, e seleção individual de informações.
- Opções persistidas em preferências.
- São apenas indicadores visuais: até identificar telemetria CANBOX, portas, porta-malas, travas, faróis, setas, freio, temperatura e combustível permanecem cinza/indisponíveis. Não exibir falso estado fechado ou travado.
- O equalizador foi mantido; balanço, fader e graves dependem de integração com serviço OEM da Jancar, ainda não implementada nesta versão.
- Compilação Android e verificação no veículo ainda pendentes.

# Peugeot 308 Launcher v1.29 — revisão de uso no carro

Base: **v1.28**, mesma identidade visual, tema e componentes anteriores.
Versão Android: **1.29**, `versionCode 129`, pacote `com.peugeot308.oem`.

## Alterações

1. **Atalhos da Home:** recolhimento após 3 minutos (180 segundos) sem toque, com transição de opacidade em 550 ms. O toque na área inferior permite mostrar os atalhos de novo.
2. **Spotify:** tocar no fundo do card não abre mais o aplicativo. Só a capa do álbum abre Spotify. Os botões de playback e Letras permanecem clicáveis.
3. **Letras:** janela redesenhada no estilo do launcher; mantém busca de LRCLIB (serviço não oficial) e edição manual de letras autorizadas.
4. **Spotify compacto:** botão Letras menor e logo abaixo da capa, sem tocar a área dos botões de reprodução.
5. **Card do veículo:** liga/desliga na primeira seção de Config. → Veículo, com explicação de que o PC do topo e os mini-cards são independentes.
6. **Volume:** os botões +/− solicitam ajuste real pelo AudioManager e verificam se o Android alterou o valor, com tentativa alternativa via `setStreamVolume`. O painel de MUDO permanece fixo e vermelho como na 1.28; o áudio volta com rampa de 1,5 s. Em central com volume fixo/MCU, aparece diagnóstico em vez de afirmar que funciona.
7. **Botões do topo:** no máximo 4 atalhos opcionais além de Config (máximo total 5). Em Aparência, é possível selecionar um app instalado para um botão personalizado. O botão Config é fixo.
8. **Bússola:** substitui RUMO; mostra Norte, Nordeste, Leste, etc. A opção GPS Precisão (metros) foi adicionada aos mini-cards e indicadores.
9. **Radar:** Config. → Alertas → Ver diagnóstico e consultar radares mostra estado do GPS, internet, precisão, data da última consulta, quantidade de pontos OSM em 7 km, mensagem de erro, consulta manual e teste simulado do alerta.
10. **Clima pelo GPS:** tenta identificar o nome da cidade por Geocoder Android, com busca de reserva no OpenStreetMap, durante a atualização do clima (não a cada posição). Mostra Cidade não identificada quando a fonte falha, em vez de confundir GPS com nome da cidade.
11. **Wi-Fi:** a v1.29 não liga nem desliga o Wi-Fi da central; o relatório agora distingue Wi-Fi ligado de conectividade com internet.

## Limitações reais

- **Volume Jancar/MCU:** `AudioManager` não é a mesma coisa que o volume nativo do rádio. O volume pode continuar sem resposta audível se a MCU ignorar comandos Android. Esta versão fornece diagnóstico; não implementa API OEM ainda desconhecida. Use Config. → Som → Diagnóstico.
- **Radares:** consultas experimentais ao OpenStreetMap/Overpass, não são uma base oficial completa. O alerta visual do launcher só é mostrado quando **o próprio launcher está em primeiro plano**. Se Waze estiver aberto, esta implementação **não garante avisos em segundo plano**. Não dependa deste recurso como único aviso.
- **Letras:** a LRCLIB depende de internet e cobertura do catálogo. Nem toda faixa estará disponível.
- **GPS:** os dados podem estar desatualizados ou imprecisos. Bússola requer movimento e leitura de direção válida.
- **CANBUS Raise:** telemetria OEM permanece não validada. Não são enviados comandos de controle da MCU.

## Teste inicial com carro parado

1. Confirmar versão 1.29/129. Não desinstale o aplicativo antigo; atualize com a assinatura original.
2. Em Config. → Som → Diagnóstico, verifique volume Android e volume fixo. Teste +/− e MUDO em volume baixo.
3. Em Config. → Alertas → Ver diagnóstico, com GPS e internet, toque **Consultar agora** e depois **Teste visual/sonoro**.
4. Em Config. → Clima, ative localização automática, atualize e verifique o nome da cidade.
5. Toque fora da capa do Spotify: não deve abrir o app. Toque na capa: deve abrir.
6. Teste os controles Letras com painel compacto (veículo ativado) e expandido.
7. Ajuste os atalhos no topo, no máximo 4 + Config. Selecione um app personalizado.
8. Após 3 minutos, confira a transição; toque na área de atalhos para voltar.

**Compilação:** pacote de fonte (ZIP), não APK. Compile com GitHub Actions e confirme versão e assinatura. Esta revisão não foi executada na central Jancar.

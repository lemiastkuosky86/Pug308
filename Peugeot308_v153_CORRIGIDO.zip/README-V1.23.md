# Peugeot 308 Launcher v1.23

Atualização baseada na v1.22. Preserva componentes de CANBUS, OBD2, radar e Spotify.

- Barra superior: Radar escrito por extenso, mini-cards centralizados e dimensionados de acordo com a quantidade ativa; atalhos aumentam até largura máxima para ocupar melhor o espaço.
- Botão Letras: mesma largura da capa e centralizado imediatamente abaixo dela.
- Modo recolhido (10 segundos): painéis de clima e Spotify dividem a área em duas colunas de tamanhos iguais; com o veículo ativado, clima, Spotify e veículo dividem em três colunas iguais. Todos com altura 592 e alinhamento vertical.
- Modo normal: preservado como na v1.22.
- Interações: mini-card de velocidade, botão Letras, controles Spotify e menus do veículo mantidos.

**Teste de campo:** compilar no GitHub Actions, validar assinatura e conferir toques e dimensionamento em 1280×720 na Jancar. Sem compilação Android local verificada.

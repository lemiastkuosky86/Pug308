# Peugeot 308 Launcher — v1.19 (código-fonte)

Base: projeto v1.18. Preserva pacote `com.peugeot308.oem`, configuração de assinatura e arquivos Java. **Este pacote NÃO é APK compilado**.

## Alterações da v1.19
- Separador entre indicadores superiores e controles de volume; botão MUDO com símbolo claro.
- Botões de volume `+` e `-` do topo abrem os controles; se pop-up já estiver aberto, um toque no topo não fecha/reabre o diálogo.
- Diagnóstico da fonte de dados em painel com texto quebrado e rolagem.
- Preferência **Priorizar GPS para mostrar velocidade**; sem GPS válido retorna CAN/OBD, ou `--`. Sem leituras artificiais.
- Botão **RAD** na barra superior para ativar/desativar aviso de radar via GPS (e internet); feedback sobre permissão de localização.
- Consulta de radares do OpenStreetMap (tags `highway=speed_camera` e `enforcement=maxspeed`) usando dois espelhos Overpass como fallback. **Os espelhos não são bases independentes.**
- Um alerta por radar a cada cinco minutos, evitando sobreposição contínua; testes manuais continuam em Alertas.
- Spotify: botão LETRAS reposicionado, busca opcional LRCLIB por título/artista, resposta rolável com identificação da fonte; fallback para o Spotify e letra fornecida pelo usuário. A API de sessões do Spotify não contém as letras. Pode haver músicas sem letra disponível, bloqueios de rede e restrições de direitos do provedor.
- Teclas do menu do veículo: submenu com botões nas cores do launcher.
- Abas e posição de rolagem das configurações guardadas ao fechar/retornar.
- Até quatro indicadores habilitados, com aviso (já na base 1.18, mantido).
- Ícones minimalistas específicos de YouTube, Maps/Waze e Chrome, mantendo opção Original por aplicativo nos Atalhos.
- Recolher atalhos depois de 10 s sem toque (padrão ligado, configurável em Aparência); toque na parte inferior mostra o dock novamente.
- Reforço de graves reduzido de até 3 dB para até 1,5 dB nas faixas baixas, sem BassBoost nativo.

## Limitações importantes
- **Balanço/fader**: a Jancar não disponibilizou API OEM confirmada. Os controles de prévia não mudam o áudio físico. Use os ajustes originais da Jancar até termos a integração.
- **Volume**: só o STREAM_MUSIC Android é controlado. Se a MCU possui outro volume, sincronização só após estudar a API OEM; não foi implementada uma unificação fictícia.
- **CANBOX**: leitura e comandos reais da Raise ainda não foram validados. OBD2 Bluetooth depende de ELM327 físico e pareamento.
- **Radares**: cobertura depende do cadastro OpenStreetMap e do GPS/rede. Alertas visuais só são mostrados com o launcher na tela. Não promete detectar todos os radares nem os limites legais em tempo real. Use Waze/Radarbot se precisar de avisos sobrepostos em outros apps.
- **Spotify**: letras buscam no LRCLIB, não diretamente no Spotify. Não é garantida disponibilidade. Não reproduz letras por meio da API oficial do Spotify.
- **Compilação**: não houve build Android neste ambiente (SDK/Gradle indisponível). Compile via GitHub Actions com a assinatura original e valide no carro.

## Checagem sugerida no carro
1. Confirmar `1.19 / 119` em Config. > Sistema.
2. Testar PC e desligamento/ligamento do painel.
3. Testar radar pelo botão RAD parado com GPS/internet; em Alertas usar 'Testar radar' e 'Testar velocidade'.
4. Testar Spotify com música em reprodução e permissão de acesso às notificações.
5. Testar pop-up volume com toques repetidos no topo; conferir o volume físico da Jancar.
6. Testar 'Priorizar GPS' (localização ativada e ao ar livre) e sem sinal (`--`).
7. Conferir após 10 s se os atalhos recolhem e reaparecem ao tocar na faixa inferior.
8. Verificar áudio em volume moderado. Se houver som abafado, voltar Bass a zero e usar equalizador original.

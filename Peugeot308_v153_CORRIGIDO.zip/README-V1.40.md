# Peugeot 308 Launcher v1.40 — Spotify sem sobreposição e animação suave

**Base:** projeto completo v1.39. As demais funcionalidades, configurações e temas foram preservados.

## Correções

1. **Spotify normal (com e sem painel do veículo):** o conjunto Anterior / Play / Próxima agora é centralizado exclusivamente na área à direita da capa. Capa e botão **Letras** permanecem juntos na coluna esquerda. Os controles reduzem de tamanho proporcionalmente quando a largura disponível diminui. Isso corrige o caso do print em que **Anterior** ficava em cima de **Letras** mesmo com apenas dois cards.
2. **Transição do dock/atalhos:** animação aumentada para 780 ms com aceleração/desaceleração suaves. Atalhos deslizam para baixo enquanto desaparecem e voltam pelo caminho inverso. As superfícies de Clima / Spotify / Veículo interpolam a altura de 456 a 592 unidades, sem duplicar seus fundos e sombras; os elementos internos mudam gradualmente de um layout para o outro.
3. **Toques durante a animação:** apenas a camada predominante recebe toques; dock deixa de receber toques assim que começa a recolher.
4. **Testes:** 1.870 cenários de geometria dos controles, além de regressões dos temas, letras sincronizadas e CSV, integrados ao GitHub Actions.

## O que não mudou

- Tema, fontes, cores e barra superior aprovados.
- Spotify, Letras, GPS, CANBUS/OBD2, radar, controle de volume, MUDO, clima, EQ, atalhos e menus rápidos.
- Tempo de espera até recolher atalhos: três minutos, como solicitado anteriormente.

## Compilar / instalar

O ZIP contém o **projeto-fonte completo**, não um APK. Suba o conteúdo para a raiz do repositório Pug308 e rode GitHub Actions. O APK precisa ser compilado e assinado com a chave original; o workflow existente verifica o certificado.

**Limite da validação:** os testes de geometria foram executados localmente, mas não foi possível compilar um APK Android ou executar o projeto dentro da Jancar neste ambiente. Teste com 2 e 3 cards e observe a transição dos atalhos no carro estacionado.

# Peugeot 308 Launcher v1.42 — Spotify + clima animado

Base: versão 1.41, mantendo todos os recursos e o layout aprovado da Home.

## Spotify com três cards

- Faixa de reprodução centralizada abaixo das informações: Anterior, Play e Próxima sem invadir o card do veículo ou o botão Letras.
- Modo recolhido usa faixa de reprodução equivalente.
- Modo com dois cards permanece com a organização original.

## Nova animação meteorológica (Canvas)

- Sol claro: movimento lento dos raios e pulsação sutil.
- Parcialmente nublado: raios movem e a nuvem flutua suavemente.
- Nublado: nuvens flutuam.
- Chuva/garoa: gotas caem em fases diferentes.
- Neve: pequenos flocos caem e oscilam.
- Neblina: linhas se deslocam lentamente.
- Trovoada: gotas e relâmpago com variação discreta.
- Ajuste **Configurações → Previsão do Tempo → Animar ícone do clima (leve)**, ativado por padrão.
- A animação usa Canvas, sem GIF, sem bibliotecas e sem consultas adicionais à internet. Região de redesenho limitada ao ícone do clima, ~5 FPS; pausa quando a Activity sai de primeiro plano.
- Informações meteorológicas continuam atualizando no intervalo existente (30 min).

## Verificação

- `javac -d /tmp/test WeatherMotion.java WeatherMotionTest.java` e `java -cp /tmp/test com.peugeot308.oem.WeatherMotionTest`.
- Teste de geometria da faixa Spotify disponível em `tests/MediaControlsLayoutTest.java`.
- Compilação Android via GitHub Actions e teste físico na Jancar ainda são necessários.

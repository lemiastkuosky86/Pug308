# Peugeot 308 Launcher v1.27 — Mudo discreto e restauração suave

Base: v1.26, sem alterações nos outros módulos da Home.

- MUDO ativado: indicador central com apenas alto-falante cortado e MUDO (sem barra e número).
- Após 2 segundos, badge MUDO pequeno e persistente no topo até desativar o mudo, sem capturar toques.
- Desativar MUDO: volume sobe gradualmente em aproximadamente 1,5 segundo até o valor salvo; HUD de volume aparece e some após 2 segundos.
- Botões + e - alteram o volume sem abrir menus, inclusive quando MUDO estava ligado.
- Estado de mudo explícito evita confundir zero temporário do fade com mudo acionado.
- Atualização dos frames durante rampa para acompanhar o valor da barra.

## Testar na central
1. Abrir Spotify, tocar MUDO e observar o indicador central e compacto após 2 segundos.
2. Aguardar 10 segundos: indicador MUDO deve continuar visível, sem impedir toques.
3. Desativar MUDO: o volume deve voltar em rampa suave e HUD desaparecer após ~2 segundos.
4. Testar + e - sem que um pop-up modal abra.
5. Confirmar que o volume Android é o que responde. Volume físico da MCU não é sincronizado.

**Projeto-fonte, não APK compilado.** Compile com o GitHub Actions e use o keystore original para atualizar sobre a versão instalada.

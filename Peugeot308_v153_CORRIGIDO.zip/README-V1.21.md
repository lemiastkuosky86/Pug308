# Peugeot 308 Launcher v1.21 — mini-card velocidade clicável

- Toque no mini-card **VELOCIDADE** do cabeçalho para abrir as configurações rápidas.
- Configura limite de 30 a 220 km/h em passos de 5 km/h.
- Quatro modos persistentes: apenas velocidade, visual, sonoro, visual + sonoro.
- Visual: vermelho acima do limite, alternando a cada 450 ms acima de 115% do limite.
- Sonoro: alerta no início do excesso e, se continuar, no máximo a cada 30 s. Respeita a opção global de som de alertas.
- Modo apenas velocidade: não colore nem toca por excesso.
- Sem GPS/OBD/CAN válido, indicador exibe `--`; nenhum alerta é disparado.
- Ao tocar no card em movimento (>5 km/h), ajustes são bloqueados por segurança.
- A configuração global de Alertas continua disponível e sincroniza o modo do card.
- Não altera dados de radar, CANBOX, OBD2 nem layout dos outros cards.

**Compilação:** requer Android SDK e Gradle/GitHub Actions. Código-fonte não testado em hardware.

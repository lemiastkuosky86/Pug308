# Peugeot 308 Launcher v1.41 — Spotify com três cards organizado

Base: v1.40. Sem alterações no layout aprovado de 2 cards.

## Ajustes

- **Com 3 cards na Home**: a capa e o botão Letras continuam na esquerda; título, artista e progresso continuam na direita. Os botões **Anterior / Play / Próxima** passam para uma **faixa inferior única e centralizada**, usando a largura total do Spotify abaixo da capa. Ficam maiores e simétricos, sem sobreposição.
- **Com 3 cards após recolher os atalhos**: faixa de reprodução centralizada na parte inferior do Spotify expandido.
- **Com 2 cards**: a distribuição anteriormente aprovada, com botões na coluna à direita da capa, é preservada.
- **Toque**: os botões continuam com os mesmos IDs e ações; não foi introduzida nenhuma função nova em segundo plano.
- **Testes**: verificação de geometria em diferentes larguras, inclusive garantindo distância vertical do botão Letras.

## Como validar

Compilar via GitHub Actions com a assinatura original. Na Jancar ou emulador 1280×720, alternar o card Veículo ligado/desligado; depois recolher os atalhos e conferir a nova faixa. Testar os três controles com música tocando.

A compilação do APK e testes no equipamento ainda dependem do GitHub Actions / Jancar.

# Peugeot 308 Launcher v1.31 — Wi-Fi opcional ao iniciar

## O que mudou

- **Configurações → Sistema → Conexões • Wi-Fi:** `Tentar ligar Wi-Fi automaticamente ao iniciar` (inicialmente desabilitado).
- Ao ativar a opção, o app solicita a ativação imediatamente se o rádio Wi-Fi estiver desligado.
- Na abertura do launcher ou ao despertar a central após período de suspensão, faz uma única tentativa, sem serviço extra em segundo plano.
- Se o Wi-Fi já estiver ativado, não altera nada.
- O aplicativo confere depois de 4 segundos se a solicitação realmente teve efeito; **não confunde solicitação aceita com Wi-Fi ligado**.
- Botões `Testar ativação` e `Abrir Wi-Fi` para diagnóstico e ativação manual, respectivamente.
- O relatório de diagnóstico inclui estado da opção e última tentativa, sem registrar redes, senhas, SSIDs ou outras informações pessoais.

## Limites técnicos

A base v1.31 mantém `targetSdk 28` e adiciona a permissão normal `CHANGE_WIFI_STATE`. O Android pode permitir `WifiManager.setWifiEnabled(true)` para aplicativos com target antigo, mas o firmware Jancar ainda pode negar ou ignorar a solicitação. Em apps que miram Android 10+, o comando geralmente é bloqueado. O app não usa root, permissões privilegiadas, ADB ou execução em loop. **Essa é uma experiência para descobrir se o firmware da sua Jancar aceita o comando, não uma garantia de automatização.**

## Instalação

Substitua o projeto antigo pelo conteúdo deste ZIP, suba ao GitHub e compile pelo workflow original com a assinatura previamente configurada. A versão Android é `versionCode 131`, `versionName 1.31`.

## Escopo preservado

Visual, Spotify, clima, radar, volume, MUDO, equalizador, CANBUS/OBD2, layout responsivo, 2/3 cards do veículo e demais opções da v1.30 permaneceram como antes.

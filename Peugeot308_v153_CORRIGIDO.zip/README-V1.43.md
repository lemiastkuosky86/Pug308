# Peugeot 308 OEM Launcher — v1.43 (fonte para compilar)

Base: pacote completo v1.42. Preserva animação do clima, temas, CAN/OBD, controles, layout normal e transição de 780 ms.

## Radar
- Elimina o desaparecimento após 3,5 s: o aviso é atualizado a cada leitura do GPS, até o ponto ser ultrapassado ou deixar de corresponder ao sentido.
- Bipes progressivos por faixa de distância; alarme visual pode ser ocultado por 10 s ao tocar nele, sem impedir toques nas demais áreas.
- Inclui 108.293 pontos distintos do arquivo Tracksource 7Ways enviado, organizados em 7 categorias (radar, lombada, lombada rodoviária, polícia, pedágio, perigo, área de risco).
- Importação pessoal por seletor de arquivos Android (TXT, CSV, ZIP); escolha entre **Adicionar** e **Substituir** somente a base pessoal. A Tracksource integrada permanece independente e offline.
- Lê as colunas reais `IDX,X,Y,Type,Speed,DirType,Direction`, mantém direções por ponto e carrega arquivos de dados pessoais v1/v2.
- RAR não é importado diretamente no Android: o arquivo recebido foi convertido em `tracksource_7ways.zip`, incorporado ao projeto e também disponibilizado separadamente.

## Spotify
- Capa ampla, preenchendo o card no modo recolhido; música/artista no rodapé sobre degradê. Sem controles de reprodução nesse modo. O layout normal conserva os botões.
- Ao mudar a faixa, a tela não mantém de propósito o mesmo bitmap da música anterior; aceita uma nova imagem quando os metadados são atualizados. A sincronização final depende do evento recebido do Spotify via MediaSession.

## Testes efetuados
- `javac` e execução dos testes `RadarCsvSmokeTest` e `TracksourceImportTest`.
- Extração e validação de todas as sete listas Tracksource: 108.500 pontos originais, 108.293 após desduplicação.

## Limitações de validação
- Sem Android SDK/Gradle no ambiente disponível; **APK não compilado** e execução física na Jancar não verificada.
- Verificar em carro parado os alertas e a interface antes de confiar no detector, que é apenas auxiliar de sinalização.
- Para atualização sobre a instalação atual, o APK deve ser assinado com a mesma chave utilizada anteriormente.

## Revisão técnica antes do carro
- Pacote ZIP validado e testes Java executados localmente.
- Workflow corrigido para publicar artefato v1.43 e executar TracksourceImportTest.
- Ainda falta compilação Android no GitHub Actions e teste em equipamento real.

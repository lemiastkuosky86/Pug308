# Atualização v1.16 — manutenção sobre v1.15

## Implementado (preservado o desenho principal)
- Corrigido filtro que escondia indicadores sem dados: opções marcadas agora exibem `--`, sem inventar valores CAN.
- Controles do veículo: menu auxiliar e seleção de próxima página de indicadores; botão de acesso configurável.
- Prévia em miniatura para os temas existentes; texto do cabeçalho personalizável e animação de brilho mais rápida.
- Repositório GitHub padrão lemiastkuosky86/Pug308.
- Clima por GPS opcional (coordenadas reais), atualização com intervalo padrão de 30 min e ao deslocar mais de 15 km. Sem GPS ou internet não há dados novos.
- Ícones originais ou minimalistas nos favoritos (alternância geral em Atalhos; MIN/ORIG por app no menu Apps).
- Marcador discreto do último app aberto pelo launcher; não é confirmação de app em execução.
- Pop-up volume: silenciar apenas no botão dedicado, não ao tocar acima de +/-; mudo só sai no botão de reativar.
- Sons de alerta radar e limite de velocidade diferenciados.
- Reforço de grave via bandas EQ, desativado BassBoost separado (o comportamento exato depende do DSP).
- Texto de configuração corrigido: balance/fader não têm efeito confirmado na Jancar.

## Ainda depende de hardware, dados externos ou validação
- CANBUS: descoberta de interface não prova telemetria; não habilitamos falso CAN conectado.
- Balanço/fader/loudness: precisam ser avaliados com Jancar e serviço de áudio OEM; nenhum comando perigoso foi acrescentado.
- Spotify: opção LETRAS permite mostrar e cadastrar texto fornecido pelo usuário para a faixa atual. Não há busca automática ou sincronização, pois sessão de mídia não disponibiliza letras.
- LED do último app é indicador de último aberto, não estado de processo (Android limita acesso).
- Ícone individual alterna entre original e minimalista; importar ícones personalizados ainda não está disponível.
- Aviso sonoro de radar depende de dados disponíveis (OpenStreetMap) e do launcher em primeiro plano.

Projeto não compilado neste ambiente. Use GitHub Actions com os Secrets da assinatura original; confira build e assinatura antes de instalar.

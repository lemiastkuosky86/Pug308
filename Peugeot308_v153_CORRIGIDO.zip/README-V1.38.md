# Peugeot 308 Launcher — Versão 1.38 (138)

## Corrigido

- **Volume:** três botões centralizados e de tamanho igual, com um único divisor à direita do grupo (nenhum separador duplicado dentro dele).
- **Spotify 2/3 cards:** títulos e artistas restritos à largura disponível e com corte por reticências; controles anterior/play/próxima dimensionados em função da largura real do card, sem invadir o painel do veículo.
- **Letras sincronizadas:** suporte a `syncedLyrics` da LRCLIB em formato LRC, destaque automático da linha atual e rolagem suave; fallback para `plainLyrics` ou texto manual quando não há marcações; atualização pela posição de mídia Android. O aplicativo não fornece letras por conta própria.
- **Aplicativos instalados:** em **Apps**, botão `⋮` ao lado de cada aplicativo permite renomear somente o atalho, restaurar nome, subir/descer na lista; favoritos também podem ser movidos à esquerda/direita na dock. As escolhas ficam em SharedPreferences e sobrevivem ao reinício.
- **Brilho:** modo noturno manual e brilho automático passam a usar o limite noturno esperado; percentual agora é rotulado de "solicitado", não uma medição do painel. Segurar o botão Brilho por 3 segundos tolera pequenos movimentos do dedo e abre o ajuste manual. Toque breve continua alternando os perfis.
- **Temas:** os temas Preto e Chumbo mantêm suas superfícies escuras no modo automático, mesmo de dia, salvo se o usuário escolher explicitamente Claro. Prévia das cores com amostra maior e coerente. Evita redesenhos contínuos devido a divergência dia/noite desses presets.
- **Spotify:** evita uma consulta de mídia redundante após a ação. Resposta efetiva do áudio continua dependendo do Spotify e da multimídia.
- **Controle PS4:** em **Rede → Testar controle USB/PS4** ou **Configurações → Sistema**, diagnóstico lê dispositivos HID/joystick reconhecidos pelo Android. **Não altera nem conserta a pilha Bluetooth da Jancar**.

## Limitações

- Não há garantia de emparelhamento Bluetooth do DualShock 4; testar primeiro nas configurações Bluetooth do Android e com cabo USB de dados. O adaptador USB 8BitDo Wireless Adapter 2 é uma opção externa se a porta USB da Jancar operar como host/OTG; não foi testado neste aparelho.
- Letras só são sincronizadas se a LRCLIB fornecer marcações LRC e o Spotify oferecer posição de reprodução válida pelo Android.
- Ajuste de brilho do aplicativo pode não regular o brilho físico controlado pela MCU da Jancar.
- O código foi revisto e o parser LRC testado com Java puro; compilação Android e testes físicos ficam para GitHub Actions e Jancar.
- As demais funcionalidades são preservadas da base 1.37, sem mudança intencional no protocolo CANBUS, radar, GPS ou equalizador.

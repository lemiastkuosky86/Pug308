# Peugeot 308 Launcher v1.44 — somente velocidade

Removidos os avisos de radares, categorias, pesquisas OSM, importação TXT/CSV/ZIP, banco Tracksource e atalhos de radar. Mantidos o velocímetro GPS, aviso de excesso de velocidade configurável, demais cards, Spotify, clima, tema e áudio. A integração OEM de balanço/fader e o Bluetooth HID requerem investigação adicional; não são anunciados como corrigidos nesta versão.

# Checklist da v1.39 na Jancar RK3326 — testar com carro parado

1. **Versão:** confira 1.39 (139) no menu Sistema antes de instalar por cima; se a
   assinatura não bater, não desinstale o launcher existente para forçar a instalação.
2. **Temas:** abra Configurações → Aparência. Selecione Peugeot Âmbar, Preto Vermelho,
   Chumbo Âmbar, Chumbo Azul, Azul Peugeot, Violeta e Gelo. Compare cada miniatura com
   a tela. Alternar entre Automático, Escuro e Claro; veja contraste e os submenus.
3. **Brilho:** selecione Mínimo, Máximo e Auto. Segure Brilho 3 segundos com carro parado
   para abrir o ajuste manual. Confirme dia/noite e o percentual *solicitado*, não medido.
4. **Spotify com veículo ligado:** escolha música com nome muito longo, toque Anterior,
   Play e Próximo. Confira se botões e título permanecem dentro da área do Spotify.
5. **Spotify com veículo oculto:** confira os controles com card largo e no modo recolhido.
6. **Letras:** uma música com LRC sincronizado destaca a linha correta; sem LRC,
   aparece texto convencional.
7. **Apps:** renomeie um atalho, mova-o para cima e para baixo, reinicie launcher
   e confira se a ordem e os nomes foram mantidos.
8. **Volume:** testar −, +, MUDO e retorno gradual. Confira o separador e áreas de toque.
9. **Radar:** importar base legítima, verificar contagem de pontos, raio geográfico, diagnóstico e teste
   visual/sonoro. Não confundir teste simulado com cobertura garantida em estradas.
10. **PS4:** testar primeiro Bluetooth nativo do Android. Se não conectar, testar USB de
    dados. O APK do launcher não substitui a pilha HID da Jancar.

# Peugeot 308 Launcher v1.32 — submenus rápidos e radar pessoal

Base: v1.31. Mantido o visual aprovado e o equalizador completo em sua tela independente.

## Tela inicial

- **Radar:** toque abre controle rápido. Liga/desliga geral, aviso visual e sonoro independentes, sete categorias: radar fixo, radar móvel (local conhecido), semáforo com câmera, semáforo com radar, polícia rodoviária, pedágio e lombada. Inclui teste, diagnóstico, consulta OSM e importação de arquivo pessoal CSV/ZIP.
- **Conexões:** agrupa Wi-Fi e Bluetooth num submenu. Inclui status, Wi-Fi automático opcional ao despertar, abertura das configurações Android e escolha de adaptador OBD2 pareado.
- **Veículo:** mostra/oculta card grande e mini-cards, escolhe 2 ou 3 cards do painel, configura cada posição, fonte de dados CANBOX/OBD2, velocidade GPS e aviso de velocidade, oferece diagnóstico.
- **EQ:** permanece em botão independente e abre a tela completa, sem substituir ajustes por submenu resumido.
- **Config:** sempre visível. A barra continua limitada a quatro atalhos adicionais.

## Radar e radar móvel

- Importação pessoal de **CSV ou ZIP contendo CSVs** via seletor de arquivos do Android, sem automação de download e sem incluir bases de terceiros no projeto.
- Os pontos importados ficam em `radar_personal.dat` no armazenamento privado do aplicativo. Funcionam **offline** quando há GPS válido e o launcher está na frente.
- A leitura identifica tipos pelas colunas `latitude`, `longitude`, `tipo`/`categoria`, `limite` e por títulos/nomes de arquivo comuns. A saída real do MapaRadar pode variar; um CSV exportado precisa ser testado para confirmar a compatibilidade.
- *Radar móvel* significa **local cadastrado de fiscalização eventual**, não equipamento detectado em tempo real. O app **não detecta** agentes ou radares que tenham sido instalados em locais não cadastrados.
- Consulta complementar online do OpenStreetMap/Overpass para radares **fixos**, lombadas e pedágios mapeados. Há cache em memória, consultas distanciadas e fallback de servidor; ambos servidores usam **a mesma fonte OSM**, não bases independentes.
- Critérios do aviso: posição GPS recente, precisão suficiente, velocidade mínima, rumo de aproximação e ponto dentro da distância configurada automaticamente em função da velocidade. Sem garantia de precisão ou cobertura de todos os pontos.
- Até 7 categorias são configuráveis separadamente. Aviso sonoro usa o volume de mídia do Android e pode depender do volume/MCU da Jancar.
- O mapa e o GPS não inferem radares móveis em tempo real. Siga a sinalização e os limites de velocidade independentemente do alerta.

## Licença e uso

O aplicativo **não inclui** a base do MapaRadar nem faz scraping, login automático ou downloads por scripts. O usuário obtém o arquivo conforme o processo oficial do provedor, respeitando os termos de uso. A importação é para uso local no carro; não redistribua os arquivos de terceiros.

## Compilação

Abra o projeto no GitHub com o workflow existente, mantendo os secrets da assinatura original. O workflow interrompe a publicação se o certificado do APK não corresponder ao anterior. `versionCode 132` e `versionName 1.32`.

## Limitações ainda não resolvidas

- Os comandos RT4 e telemetria Jancar ainda não têm interface Binder de leitura validada.
- Fader/balanço e volume único da MCU exigem integração OEM específica.
- Os serviços de alerta funcionam no primeiro plano; o aplicativo não mantém serviço de radar em segundo plano e não possui mapa embarcado.
- A importação MapaRadar pode exigir ajuste do parser após analisar um CSV real fornecido pelo usuário.

# Peugeot 308 Launcher — v1.47

Base: v1.46. Atualização conservadora de inicialização e áudio.

- Fade automático de inicialização desativado em migração única; continua disponível nas configurações.
- Removida repetição do fade ao detectar Spotify retomando reprodução. Não manipula a saída OEM, nem promete sanar problemas externos de áudio/roteamento.
- Ativação automática do Wi-Fi habilitada em migração única; tenta em segundo plano sem abrir configurações, somente se o Android permitir. Após migração, opção do usuário é preservada.
- Launcher mantém intent HOME; torná-lo o launcher padrão depende das configurações e do firmware Jancar. Não há como impedir a tela OEM do Wi-Fi com permissões comuns se ela for lançada pelo sistema.
- Não removidos componentes de Bluetooth, CANBUS, temas, animações ou Spotify. Recomenda-se otimização apenas após perfil de CPU/memória, para evitar regressões.
- Compatibilidade com assinatura depende dos segredos originais do GitHub Actions; conferir APK antes de instalar.

**Limitações:** sem teste físico na Jancar; o comportamento de Spotify e o firmware de Wi-Fi precisam de validação no carro.

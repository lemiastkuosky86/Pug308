package com.peugeot308.oem;

public class RadarGeoTest {
    private static void require(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    public static void main(String[] args){
        require(RadarGeo.candidate(250,0,4,5,-1),"radar à frente não detectado");
        require(RadarGeo.candidate(350,359,1,7,-1),"rumo 359/1 deve ser próximo");
        require(!RadarGeo.candidate(320,0,20,5,-1),"rua lateral distante aceita");
        require(!RadarGeo.candidate(250,0,0,5,180),"sentido oposto aceito");
        require(RadarGeo.candidate(250,0,0,5,55),"sentido conhecido tolerável rejeitado");
        require(!RadarGeo.candidate(250,0,0,45,-1),"GPS muito impreciso aceito");
        require(!RadarGeo.candidate(400,0,0,5,-1),"radar distante aceito");
        require(!RadarGeo.candidate(5,0,0,5,-1),"radar já ultrapassado aceito");
        System.out.println("RadarGeoTest OK (8 casos)");
    }
}

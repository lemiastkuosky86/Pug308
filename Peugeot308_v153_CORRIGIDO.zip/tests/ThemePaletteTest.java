package com.peugeot308.oem;
public class ThemePaletteTest {
    public static void main(String[] args){
        int[] accents={0xffFFA21A, 0xffFF4B4B, 0xff3FD68B, 0xffEFE9DC, 0xff4DA3FF,
            0xffFFB454,0xffFF8C42,0xffFF6B6B,0xff5FD39A,0xff62AFFF,0xff4CD0D8,0xffE4E7EB,
            0xff00aeff,0xfffa5965,0xff29d6a4,0xffffae46,0xffae86ff,0xff8fa3b8,0xff2ecc71,0xff22d3ee,
            0xff14b8a6,0xffa3e635,0xfffacc15,0xfffb923c,0xffef4444,0xfff472b6,0xffd946ef,
            0xff6366f1,0xff3b82f6,0xffd4a24c,0xffc2415b,0xffbae6fd};
        int failures=0,checks=0;
        for(int idx=0;idx<accents.length;idx++)for(int mode=0;mode<3;mode++)for(int night=0;night<2;night++){
            ThemePalette p=ThemePalette.create(idx,mode,night==1,accents[idx]);checks++;
            if(p.dark != (mode==1 || mode==0 && (idx<12 || night==1))) { System.out.println("Night fail "+idx+" "+mode);failures++; }
            if(ThemePalette.contrast(p.text,p.surfTop)<7.0) {System.out.println("Text fail "+idx+" "+mode+" contrast "+ThemePalette.contrast(p.text,p.surfTop)); failures++;}
            if(ThemePalette.contrast(p.accent,p.surfTop)<4.5){System.out.println("Accent fail "+idx+" "+mode+" contrast "+ThemePalette.contrast(p.accent,p.surfTop));failures++;}
            if(ThemePalette.contrast(p.onAccent,p.accent)<4.5){System.out.println("Button fail "+idx+" "+mode);failures++;}
        }
        if(failures>0)throw new AssertionError(failures+" falhas em "+checks+" estados de paletas");
        System.out.println("PASS: "+checks+" paletas, contraste de texto, botões e destaques.");
    }
}

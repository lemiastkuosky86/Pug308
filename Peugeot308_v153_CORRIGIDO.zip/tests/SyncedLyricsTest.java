import com.peugeot308.oem.SyncedLyrics;
import java.util.List;
public class SyncedLyricsTest {
    public static void main(String[] args) {
        List<SyncedLyrics.Line> lines=SyncedLyrics.parse("[ar:artist]\n[00:01.00]Primeira\n[00:02.50][00:03.75]Segunda\n[01:00.2]Fim\n[02:03.456] ");
        if(lines.size()!=5)throw new AssertionError("linhas="+lines.size());
        if(lines.get(1).startMs!=2500 || lines.get(2).startMs!=3750)throw new AssertionError("tempo");
        if(lines.get(3).startMs!=60200)throw new AssertionError("décimos");
        if(SyncedLyrics.activeLine(lines,200)!=-1 || SyncedLyrics.activeLine(lines,2800)!=1 || SyncedLyrics.activeLine(lines,80000)!=3)throw new AssertionError("sincronização");
        if(!SyncedLyrics.parse("[ti:x]\nmalformado").isEmpty())throw new AssertionError("inválido");
        System.out.println("OK: interpretação de LRC, marcações e linha ativa");
    }
}

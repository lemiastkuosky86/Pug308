package com.peugeot308.oem;

/** Testes geométricos dos botões de reprodução para 2 e 3 cards. */
public class MediaControlsLayoutTest {
    private static void check(boolean condition,String message){
        if(!condition) throw new AssertionError(message);
    }
    public static void main(String[] args){
        int count=0;
        // Mantém a compatibilidade com o layout recolhido da versão anterior.
        for(int width=180;width<=862;width+=2)
            for(boolean compact:new boolean[]{false,true})
                for(boolean idle:new boolean[]{false,true}){
                    MediaControlsLayout m=MediaControlsLayout.forWidth(width,compact,idle);
                    check(m.separation+m.sideRadius <= width/2f-13.5f,"extravasa card: "+width);
                    check(m.separation >= m.sideRadius+m.playRadius+4,"botões se sobrepõem: "+width);
                    count++;
                }
        // Novo layout: TODOS os controles normais ficam à direita da capa e das Letras.
        for(int width=400;width<=900;width+=2){
            for(boolean wide:new boolean[]{false,true}){
                float x=386f;
                float art=wide?Math.min(300f,width*.36f):Math.min(216f,Math.max(120f,width*.34f));
                float ax=x+32f;
                float tx=ax+art+(wide?36f:22f);
                float right=x+width-26f;
                if(right-tx<90) continue; // largura não usada pelo launcher
                MediaControlsLayout m=MediaControlsLayout.forRegion(tx,right,!wide,false);
                float prevLeft=m.centerX-m.separation-m.sideRadius;
                float prevRight=m.centerX-m.separation+m.sideRadius;
                float playLeft=m.centerX-m.playRadius;
                float playRight=m.centerX+m.playRadius;
                float nextLeft=m.centerX+m.separation-m.sideRadius;
                float nextRight=m.centerX+m.separation+m.sideRadius;
                check(prevLeft>=tx+8f,"Anterior invade a coluna Letras: "+width+" / "+wide);
                check(nextRight<=right-8f,"Próxima invade card vizinho: "+width+" / "+wide);
                check(prevRight+5f<=playLeft,"Anterior sobrepõe Play: "+width+" / "+wide);
                check(playRight+5f<=nextLeft,"Play sobrepõe Próxima: "+width+" / "+wide);
                count++;
            }
        }
        // Layout v1.41: os controles compactos ocupam uma faixa inferior
        // reservada, longe da capa, do Letras e das informacoes da musica.
        for(int width=410;width<=570;width+=2) {
            for(boolean idle:new boolean[]{false,true}) {
                float x=386f,y=96f;
                float rackX=x+24f, rackW=width-48f;
                float rackY=y+(idle?444f:309f), rackH=idle?120f:114f;
                MediaControlsLayout m=MediaControlsLayout.forFooter(rackX+22f,rackX+rackW-22f,idle);
                float leftEdge=m.centerX-m.separation-m.sideRadius;
                float rightEdge=m.centerX+m.separation+m.sideRadius;
                float cy=y+(idle?502f:366f);
                float topEdge=cy-m.playRadius;
                float bottomEdge=cy+m.playRadius;
                check(leftEdge >= rackX+8f,"Anterior sai da faixa: "+width);
                check(rightEdge <= rackX+rackW-8f,"Proxima sai da faixa: "+width);
                check(m.separation >= m.sideRadius+m.playRadius+5f,"Controles se encostam: "+width);
                check(topEdge >= rackY+2f,"Play acima da faixa: "+width);
                check(bottomEdge <= rackY+rackH-2f,"Play abaixo da faixa: "+width);
                if(!idle) {
                    float art=Math.min(216f,Math.max(120f,width*.34f));
                    float lyricsBottom=172f+art+5f+27f;
                    check(lyricsBottom+14f <= topEdge,"Letras encosta nos controles: "+width);
                }
                count++;
            }
        }
        System.out.println("PASS: "+count+" verificações de controles do Spotify, inclusive faixa compacta v1.41.");
    }
}

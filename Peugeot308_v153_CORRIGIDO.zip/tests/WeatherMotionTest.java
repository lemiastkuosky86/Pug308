package com.peugeot308.oem;
public final class WeatherMotionTest {
    private static void check(boolean ok,String message) { if(!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        for (long t=0;t<10000;t+=50) for (int i=0;i<4;i++) {
            float v=WeatherMotion.progress(t,1200L,i,4);
            check(v>=0 && v<1,"invalid phase="+v);
        }
        check(WeatherMotion.progress(1200,1200,0,3)==0f,"period rollover");
        check(Math.abs(WeatherMotion.progress(0,1200,1,3)-1f/3f)<1e-6,"phase stagger");
        check(WeatherMotion.progress(0,0,0,0)==0,"invalid params");
        System.out.println("PASS: weather phase, rollover and stagger");
    }
}

# Checklist de validação v1.42 — com o carro estacionado

1. Com o **card Veículo ligado** (três cards), testar Anterior/Play/Próxima, verificar a faixa inferior no Spotify e confirmar que Letras permanece separado da faixa.
2. Recolher os atalhos e confirmar os mesmos controles na faixa inferior; ao expandir, verificar que não surgem botões duplicados.
3. Desligar o card Veículo (dois cards) e confirmar o layout amplo do Spotify preservado.
4. Em Clima, confirmar que sol/nuvem/chuva animam conforme a condição atual. Em **Configurações → Previsão do Tempo**, desligar **Animar ícone do clima (leve)** e verificar que o ícone fica estático. Reativar.
5. Minimizar o launcher/abrir outro aplicativo e voltar; verificar que a animação retoma sem travamentos.
6. Confirmar se o nome da cidade, o botão Radar, Wi-Fi, volume/MUDO, temas e brilho continuam como na versão anterior.

**Nota**: valores e condição do clima continuam dependendo da consulta meteorológica existente, não da animação. Compilação Android e testes físicos não foram realizados neste ambiente.

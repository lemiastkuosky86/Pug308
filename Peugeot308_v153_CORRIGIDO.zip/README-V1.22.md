# Peugeot 308 Launcher v1.22

Base: projeto v1.21, sem alterações na estrutura das telas principais.

- Barra superior: botões redistribuídos com espaço uniforme; indicadores e volume separados.
- Configurações > Aparência > Barra superior: mostrar/ocultar botões de volume, Bluetooth, Wi-Fi, Radar, PC de bordo e EQ. O botão Configurações permanece sempre presente.
- Ocultar um botão não desativa o serviço correspondente (Bluetooth, Wi-Fi ou radar).
- Spotify: botão Letras discreto, centralizado abaixo da capa, sem sobrepor os controles e textos. A busca de letras permanece a mesma da v1.21 (LRCLIB).
- Removida a mensagem 'Toque para mostrar os atalhos' na tela inicial recolhida. Um toque na área inferior ainda revela os atalhos.
- Versão Android: 1.22 (versionCode 122).

Este pacote é o código-fonte, ainda não compilado nem testado em central real.

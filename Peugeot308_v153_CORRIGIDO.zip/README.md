**Novidade v1.53:** ver [README-V1.53-RADAR.md](README-V1.53-RADAR.md) para correções do radar, serviço e simulação.

# Peugeot 308 Launcher — v1.50

Projeto Android em Java para a Jancar. Esta versão parte da **v1.49 corrigida para compilação** e remove a última constante e o último desenho vetorial não utilizados do antigo sistema de radares.

**Permanecem:** indicador de velocidade por GPS, configuração de limite e avisos de excesso de velocidade, tema, Spotify, clima, CANBUS/OBD2, diagnóstico e exportação de logs.

O código de execução do aplicativo (`app/src/main`) não contém mais referências a radares. Arquivos `README-V1.xx.md` e `CHECKLIST-V1.xx.md` são **históricos** de versões antigas e não orientam o teste atual.

Para compilar, execute o fluxo GitHub Actions `Compilar Peugeot 308 APK` com os secrets de assinatura original. O projeto-fonte ZIP não é um APK pronto para instalar.

Veja `README-V1.50.md`, `CHECKLIST-TESTE-CARRO.md` e `INSTRUCOES-GITHUB.md`.

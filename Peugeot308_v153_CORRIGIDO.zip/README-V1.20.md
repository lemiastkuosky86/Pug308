# Peugeot 308 Launcher — v1.20 (código-fonte)

Base exata: v1.19. Pacote Android preservado `com.peugeot308.oem`; versionCode 120, versionName 1.20. Sem alterações de layout fora da área dos mini cards.

## Ajustes

- Configurações > Veículo > Mini cards: cada Card 1/2/3 tem opção **Desligado (não mostrar)**, já suportada internamente por `-1`; a opção foi explicitada.
- Botão **Desligar os 3 mini cards** desliga todos de uma vez, salva nas preferências e atualiza a tela. Se todos desligados, nenhum aparece no topo. Se um ativo, apenas um aparece.
- **Mini card VELOCIDADE**: quando há dado de velocidade válido (GPS preferencial pela opção existente, ou CAN/OBD conforme disponibilidade), acima do limite fica vermelho; acima de **115% do limite** pisca em vermelho com ciclo de 450 ms. Sem leitura real, não acende nem pisca.
- **Limite de velocidade do mini card** configurável de 30 a 220 km/h, em passos de 5 km/h, reutilizando a preferência `speed_limit` e mantendo o limite do alerta existente sincronizado.
- A indicação vermelha do mini card funciona independentemente do alerta sonoro/pop-up (habilitado separadamente na aba Alertas). O mini card de LIMITE não é tratado como velocidade atual.
- Blink usa o agendamento de atualização do cabeçalho existente, evitando segundo loop de animação.

## Teste no carro
1. Config. > Veículo > Mini cards: desligue 2 e deixe apenas Velocidade; confirme que aparece apenas 1. Desligue o último e verifique barra sem cards.
2. Ative a preferência existente 'Priorizar GPS para mostrar velocidade', obtenha localização válida e escolha um limite adequado **sem ultrapassar limites legais**. Simule o desenho do alerta em ambiente controlado ou revise estaticamente; não dirija acima do limite para testar.
3. Atenção: GPS pode ter atraso; esse indicador não substitui o velocímetro nem determina o limite legal da via.

**Não compilado em APK neste ambiente**. Compilar pelo GitHub Actions com o keystore original.

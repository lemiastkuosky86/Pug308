# Peugeot 308 Launcher v1.15 — integração inicial Jancar

## Garantia de preservação da interface

A versão 1.15 mantém todos os métodos de desenho, as áreas de toque, os temas, Spotify, relógio, clima, favoritos, atualizações e equalizador do código 1.14. A única adição visível é um grupo pequeno de botões na área já existente **Configurações → Veículo**.

## Integração implementada

- Ação OEM `com.jancar.services.action.car` e descriptor `com.jancar.services.car.ICar` identificados no arquivo IVI Services da Jancar.
- Consulta apenas serviços Android publicamente visíveis e tenta `bindService` somente quando o serviço declara `exported` e não exige permissão ausente.
- Lê o descritor do Binder, **sem fazer transações de protocolo desconhecido**, sem modificar configurações OEM e sem enviar comandos CAN.
- Observa apenas quantidade de broadcasts `com.jancar.services.action.key.event` (evento identificado nos APKs). Não intercepta comandos do volante nem confia nesses broadcasts como telemetria.
- Adicionados botões de diagnóstico, abrir aplicativo do veículo e abrir rádio OEM em Configurações → Veículo; sem alterações na tela principal.
- O launcher ainda utiliza o GPS para velocidade quando CANBUS não está disponível, como antes.

## Limites conhecidos (importantes)

Conectar a Binder `ICar` NÃO é o mesmo que obter dados CAN. Por enquanto, o painel continua `--` para dados sem fonte comprovada. Não foram decodificados AIDL, callbacks ou campos de telemetria, nem confirmado se esse serviço aceita conexões de aplicativos não privilegiados. Não há comandos de escrita CAN, de volante ou de rádio novos.

## Teste no veículo

1. Instale via atualização normal, **sem desinstalar**, usando a chave original confirmada (SHA-256: 531C7DF8FBCB6750AD96607D38179EFA62989575C57C20185895E9AE69D62752).
2. Abra Configurações → Veículo → Diagnóstico Jancar.
3. Anote as linhas `Serviço`, `Interface Binder` e `Estado`. Aguarde 1 segundo caso apareça "Conectando" e toque em Atualizar.
4. Acione com o veículo parado um comando do volante e veja se o contador de eventos muda. Se não mudar, isso só significa que não recebemos aquele evento; não prova falha da CANBOX.
5. Não altere o protocolo Raise/PSA-RZ nem faça testes de direção em movimento.
6. Envie o texto do diagnóstico para prosseguirmos com os métodos concretos da interface disponível.

## GitHub Actions

O arquivo `.github/workflows/compilar-apk.yml` já usa os 4 Secrets de assinatura configurados anteriormente e rejeita certificados diferentes. Seu versionCode foi elevado para 115. O arquivo `update.json` corresponde a 1.15; ele não publica por conta própria uma Release.

## Validação local

Arquivos e sintaxe XML/ZIP verificados. O APK ainda precisa ser compilado no GitHub Actions e testado na Jancar. Este ambiente não dispõe do Android SDK/Gradle para executar a compilação.

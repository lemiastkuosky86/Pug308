# Teste visual v1.40 na Jancar (carro estacionado)

- [ ] Com painel Veículo **desligado** (2 cards), verificar que **Anterior** não cobre **Letras**.
- [ ] Com painel Veículo **ligado** (3 cards), verificar que Anterior, Play, Próxima cabem no Spotify.
- [ ] Título longo da música não ultrapassa o card.
- [ ] Esperar três minutos para os atalhos recolherem suavemente, sem fundos de cards duplicados.
- [ ] Tocar na região inferior para os atalhos reaparecerem suavemente.
- [ ] Tocar em Play e nas Letras durante telas estáveis (evitar interagir no meio da animação).
- [ ] Conferir se climas, radar, brilho e volume continuam respondendo.

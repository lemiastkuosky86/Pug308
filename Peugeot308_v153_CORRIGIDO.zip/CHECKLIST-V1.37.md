# Checklist v1.37 (carro parado)

1. **OBD2 na ignição:** com o adaptador conectado, ligue o carro e aguarde ~1 min. O status deve sair de "Conectando" para dados ao vivo sem você tocar em nada.
2. **OBD2 caiu:** desligue o adaptador por alguns segundos e religue; os dados devem voltar sozinhos.
3. **Fade ao ligar:** o volume sobe até o nível anterior e não fica em 0. Repita acendendo e apagando os faróis nos primeiros segundos.
4. **Mudo e volta do mudo:** funciona como antes.
5. **Dock:** nomes dos apps fixados normais; sem travar ao mexer no brilho.
6. **Ícone:** o app aparece com ícone próprio em Configurações do Android > Apps.
7. **Tema/idioma:** trocar o tema do Android não deve reabrir a tela inicial do zero.

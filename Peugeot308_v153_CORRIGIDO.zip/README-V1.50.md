# v1.50 — limpeza definitiva de resíduos do radar

Base: Peugeot308Launcher_v1_49_correcao_compilacao.zip.

## Mudanças exatas
- Removida `Dashboard.I_RADAR` (constante sem chamadas).
- Removido `case I_RADAR` do renderizador de ícones (código sem referências).
- Atualizada identificação da versão em `app/build.gradle`, `update.json` e rótulo do log de falha do GitHub Actions.
- README inicial e checklist atualizados, preservando os documentos históricos.
- Não alterado mais nenhum código funcional.

## Funcionalidades preservadas
- Velocidade por GPS e alertas configuráveis de **excesso de velocidade** (não são radares).
- Cards e temas, Spotify, Wi-Fi, áudio, CANBUS/OBD2, log e backups.

## Validação
- Busca em `app/src/main` por termos de radar: nenhuma ocorrência.
- Testes Java isolados dos temas, layout de controles e letras: passaram.
- A compilação Android final e o teste no hardware Jancar continuam pendentes; o fluxo de CI e a assinatura original devem ser usados.

## Resultado esperado
A mudança remove somente um ícone e uma constante que não eram usados, portanto a redução de tamanho será pequena e não se espera melhoria perceptível de FPS ou memória.

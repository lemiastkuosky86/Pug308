# Peugeot 308 Launcher v1.28 — MUDO fixo

Base: v1.27. Alterações restritas ao indicador e à interação do MUDO.

- Painel MUDO não diminui de tamanho e permanece centralizado até desativação explícita.
- Ícone do alto-falante cortado em vermelho; exibe apenas ícone + palavra MUDO.
- Um toque no próprio painel MUDO ou no botão Mudo da barra superior reativa o áudio.
- Os controles +/- durante o MUDO apenas ajustam o nível que será restaurado, sem sair do mudo acidentalmente.
- Continua a restauração gradual do volume (aprox. 1,5 segundo) já implementada na v1.27.
- Depois de sair do MUDO, o indicador normal de volume desaparece após 2 segundos.

**Limitação:** o controle continua atuando no volume de mídia Android, não no volume independente da MCU Jancar.

**Validação:** alteração estática revisada. Projeto ainda não compilado ou testado em veículo.

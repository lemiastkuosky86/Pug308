# Peugeot 308 Launcher v1.49 — estabilidade e diagnóstico

Base: ZIP completo da v1.48. Sem alterações intencionais na Home, temas, card do veículo ou layout Spotify.

## Implementado

1. **Partida/retorno:** log distingue início após boot recente de processo recriado, registra `screen_on`, `screen_off`, `resume` e `pause` e inicia monitor de rede por ciclo. O Android continua responsável por escolher o launcher HOME; se a Jancar abrir uma tela Wi-Fi OEM por cima, o app não tem privilégios para bloqueá-la.
2. **Spotify:** preservados eventos MediaSession e atualização periódica, sem reinicializar reprodução ou alterar volume. Há um botão **Diagnosticar Spotify agora** nas Configurações > Sistema, que verifica a sessão, estado e volume e guarda evidências. Quando PLAYING coincide com mudo/volume zero, o log registra suspeita limitada a um registro por minuto. O diagnóstico NÃO detecta fisicamente silêncio no amplificador; a recuperação deve ser guiada pelos logs.
3. **Wi-Fi:** monitor com até três verificações por despertar, sem abrir configurações e sem tentar associar à força a SSIDs. A tentativa de ativar o rádio acontece somente na primeira verificação e pode ser recusada pelo Android/Jancar. Eventos são registrados com horário.
4. **Eficiência:** checagem de rede e sessões de mídia menos frequente em segundo plano, redução de redesenhos redundantes no callback de rede, atualização do estado do som limitada quando a tela está pausada e não há volume automático. Preservadas animações em primeiro plano e GPS necessário.
5. **Log de campo:** preservado histórico de 512 KB sem coordenadas, SSID, nomes de músicas ou senhas, com exportação TXT. Requer opção ativada; processo pode ser suspenso pela Jancar.
6. **Backup:** preservada exportação e restauração de preferências visuais da v1.48.

## Importante

- NÃO foram resolvidos nem simulados balanço/fader/megagraves: dependem da API OEM Jancar.
- Não há garantia de abrir a Home acima da tela Wi-Fi exibida pelo próprio firmware; defina o launcher como HOME padrão e verifique configuração OEM de inicialização.
- Não forçamos reinício do Spotify: travamentos de áudio podem depender de foco de áudio e MCU fora do alcance do app.
- Compilar o APK no GitHub Actions com os 4 secrets da assinatura original. A ação verifica o certificado antes de disponibilizar o APK.

## Uma visita ao carro

1. Antes de instalar, salve backup de aparência na v1.48 se disponível.
2. Compile o projeto v1.49 pelo GitHub Actions, confirme assinatura e instale o APK.
3. Abra Configurações > Sistema, habilite log e mantenha Wi-Fi automático ligado.
4. Saia da central e retorne após desligá-la; repita com Spotify.
5. Se o Spotify apresentar barra avançando sem som, toque em **Diagnosticar Spotify agora** sem pausar a música.
6. Exporte o TXT e, se houver, o relatório de sistema, anotando horário aproximado do defeito.

# Peugeot 308 Launcher — v1.25

Alterações somente na barra superior:

- Mini-cards do topo: títulos, números e unidades centralizados horizontalmente.
- Atalhos do topo: ícone + legenda centralizados como um grupo.
- Removido o ponto final de **Config.**: agora **Config**.
- Substituídos os três botões de volume do topo por **um único botão Volume** que abre o popup existente.
- Os controles de diminuir, aumentar, mudo e barra deslizante continuam no popup.
- Ajustada a legenda da opção de visibilidade em Aparência → Barra superior.

Demais telas, lógica de CANBUS, radar, Spotify e painel de clima preservadas.

**Ainda não testado/compilado em hardware Jancar.** As mudanças de volume afetam somente o fluxo de interface, não unificam os volumes Android e MCU.

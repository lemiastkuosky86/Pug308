# Teste Peugeot 308 Launcher v1.31 — Wi-Fi

Teste estacionado. Não altere configurações de firmware da Jancar.

1. Em **Configurações → Sistema**, verifique a opção **Tentar ligar Wi-Fi automaticamente ao iniciar**: por padrão **desligada**.
2. Desligue manualmente o Wi-Fi nas configurações Android. Volte ao launcher, ative a nova opção: ele tenta ligar o Wi-Fi uma vez.
3. Aguarde até 5 segundos e verifique se o Wi-Fi realmente ficou **habilitado** no Android. A mensagem `solicitação enviada` sozinha **não** confirma sucesso.
4. Se não ativar, use **Abrir Wi-Fi** e confira o estado manualmente. Em **Sistema → Ver relatório**, procure `Última tentativa Wi-Fi`.
5. Deixe a opção ativada com Wi-Fi ligado, desligue o carro e teste no dia seguinte. O launcher deve fazer nova tentativa ao iniciar/acordar, mas não ficar repetindo comandos.
6. Desative a opção e confira que nenhuma tentativa automática seja feita.
7. Verifique se Spotify, radar, MUDO e clima continuam funcionando como na v1.30.

Se o Wi-Fi continuar desligado, envie apenas as linhas `Wi-Fi automático ao iniciar`, `Última tentativa Wi-Fi` e `Rádio Wi-Fi habilitado` do relatório para investigarmos a limitação do firmware.


## Testes específicos da v1.32 — carro parado

1. Confirme em Sistema/Sobre a versão **1.32 (132)**.
2. Toque no botão **Rede**: verifique Wi-Fi, Bluetooth, tentativa de ligar Wi-Fi opcional e retorno à Home.
3. Toque no botão **Radar**: ative geral, selecione categorias e configure visual/sonoro separadamente; use **Testar aviso** e **Teste móvel**.
4. Ainda em Radar, selecione **Diagnóstico**: confira permissão GPS, internet, pontos em 1,5 km e base pessoal. Mesmo parado, a consulta e o diagnóstico podem funcionar; avisos de aproximação exigem movimento.
5. Importe um arquivo pessoal CSV ou ZIP de listas CSV pela própria multimídia. Confira quantidade total, categorias e linhas ignoradas. Se um arquivo real do MapaRadar não for reconhecido, envie-o para adaptação do parser.
6. Desative o Wi-Fi e verifique: a base pessoal continua consultável; OSM não atualiza offline.
7. Toque em **Veículo**: o card grande ativa/desativa sem reiniciar; ajuste quantidade, indicadores, fonte de motor e GPS.
8. Toque em **EQ**: deve continuar abrindo o equalizador completo, não um submenu pequeno.
9. Verifique se os cinco espaços do topo respeitam **4 atalhos + Config**, sem sobreposição.
10. Não teste avisos de velocidade excedendo limites de via. Use os testes simulados com o carro estacionado.

### Limitações conhecidas

O aviso de radar móvel indica somente **local cadastrado**. O GPS não sabe se uma fiscalização está operando naquele momento. Sem arquivo pessoal compatível, a categoria móvel pode ter **zero pontos**. Não há automatização de downloads do MapaRadar. O radar depende do launcher visível. A compilação Android e o teste físico ainda dependem do GitHub Actions/Jancar.


## Atualização v1.36
Veja `CHECKLIST-V1.36.md` para os testes de início rápido, Spotify e cache.

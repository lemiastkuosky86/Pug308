# Peugeot 308 Launcher v1.36

Projeto Android/Java para a central Jancar do Peugeot 308. **Código-fonte para compilar no GitHub Actions**, não um APK instalado.

- Novidades e limitações: [`README-V1.36.md`](README-V1.36.md)
- Checklist de teste: [`CHECKLIST-V1.36.md`](CHECKLIST-V1.36.md)
- Instruções de GitHub: [`INSTRUCOES-GITHUB.md`](INSTRUCOES-GITHUB.md)

A base offline de radares não está incluída no projeto. Importe um CSV próprio obtido pelos meios oficiais e verifique as contagens no diagnóstico.

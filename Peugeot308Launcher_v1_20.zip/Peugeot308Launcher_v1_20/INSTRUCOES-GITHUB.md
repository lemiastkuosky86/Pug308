# Peugeot 308 Launcher v1.20 — GitHub Actions

## Compilar sem computador
1. Repositório **privado** no GitHub (o código e os Secrets ficam protegidos).
2. Envie os arquivos DE DENTRO desta pasta para a raiz do repositório (não o ZIP como arquivo único).
3. Em **Settings > Secrets and variables > Actions**, confira os 4 Secrets da assinatura original:
   `PEUGEOT_KEYSTORE_BASE64`, `PEUGEOT_KEYSTORE_PASSWORD`, `PEUGEOT_KEY_ALIAS`, `PEUGEOT_KEY_PASSWORD`.
4. **Actions > Compilar Peugeot 308 APK > Run workflow**.
5. Ao terminar (verde), baixe o artifact `Peugeot308Launcher-1.20-v120-assinatura-original` e use o `app-debug.apk` de dentro.

O workflow **bloqueia** o download se o APK não estiver assinado com a chave original (confere o SHA-256 do certificado). Sem a mesma chave o Android recusa a atualização por cima.
Não desinstale o launcher atual só para testar: as configurações podem ser apagadas. Nunca coloque keystore, senhas ou Base64 no repositório nem no chat.

## Dados do APK
Pacote `com.peugeot308.oem` • versão `1.20` • versionCode `120` • minSdk 26 • compileSdk 35 • Java 17 • Gradle 8.9 • AGP 8.7.3.

## Atualização automática pela central
A central consulta **GitHub Releases** (Config. > Sistema). Isso só funciona se o repositório configurado for **público** e tiver uma Release com o `.apk` anexado; um artifact do Actions **não** é uma Release, e repositório privado devolve "não encontrado".
Como não dá para deixar o código público, uma saída é criar um segundo repositório **público só para as Releases** (sem código, só o APK assinado) e configurar esse nome em Config. > Sistema > Definir repositório.
O `update.json` serve apenas para o servidor local (fonte "Servidor local").

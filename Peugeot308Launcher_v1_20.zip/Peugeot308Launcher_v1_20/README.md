# Peugeot 308 OEM Launcher v1.20

Mesma composição visual da 1.18 (nenhum cartão ou botão mudou de lugar). Esta versão é uma **revisão geral**: correções de robustez, sem recursos novos na tela.

## O que mudou na 1.20
Veja o `CHANGELOG.md` (revisão geral: volume, manifest, desempenho, atualização, clima, ícone).

## O que mudou na 1.19
- **OBD2 Bluetooth** (`ObdBluetoothReader`, reescrito):
  - **Reconecta sozinho**: se o adaptador ainda não estiver pronto quando o carro liga, se a ignição desligar ou o Bluetooth cair, tenta de novo a cada 10 s (antes desistia de vez e exigia tocar em "Conectar").
  - Corrigida uma **corrida** entre a conexão antiga e a nova (tocar em Conectar/trocar a fonte rápido podia derrubar a sessão nova).
  - **Aquecimento do protocolo** (a primeira consulta ao ELM327 demora e desalinhava as respostas seguintes) e descarte de lixo do buffer antes de cada comando.
  - **RPM e velocidade atualizam mais rápido** (sensores lentos — motor, combustível — são lidos a cada ~8 ciclos).
  - Novo: **temperatura externa** (PID 0146, quando o carro suporta). Continua **somente leitura**.
  - Sem leitura confirmada, a tela mostra `--` (não fica com valor antigo).
- **Diálogos do sistema** (escolher adaptador, diagnósticos, menu do veículo, letras): agora não deixam a barra do Android reaparecer nem deslocar a janela, como já faziam os popups do launcher.
- **Clima automático por GPS**: não consulta a internet antes de ter coordenadas (antes tentava buscar a "cidade" `Localização atual` repetidamente) e a primeira consulta sai assim que há sinal.
- **Popup de volume**: arrastar a barra cancela um fade de entrada em andamento e avisa o motor de som; ao arrastar até 0 guarda o volume anterior para o "tirar do mudo".
- **Motor de som**: removido o BassBoost que era criado só para ficar desligado (o reforço de graves já é feito pelo EQ).
- Lista de adaptadores OBD2 não mostra mais "null" para dispositivos sem nome.
- Versão `1.19` / `versionCode 119`.

## Verificação feita
O código **compila** (JDK 21 + android.jar API 35) e a lógica foi testada fora do Android com classes simuladas: leitor OBD2 contra um ELM327 simulado (leitura, reconexão, ignição desligada, Bluetooth desligado, `start()` repetido) e motor de som (loudness suave, volume por velocidade, central que ignora o ajuste de volume, limites do efeito, persistência). **Não foi testado no carro nem montado em APK**: faça o build pelo GitHub Actions e use o `CHECKLIST-TESTE-CARRO.md`.

## Limitações que dependem do carro
- **CANBOX/Jancar**: `JancarBridge` só descobre/vincula o serviço do fabricante; não há leitura validada de telemetria. Nada é simulado.
- **Áudio**: o equalizador usa o efeito do Android; se a Jancar rotear o som por DSP próprio, pode não mudar o som (use Ajustes > Testar efeito). Balanço/fader não têm API confirmada.
- **OBD2**: precisa de adaptador ELM327 Bluetooth **clássico** já pareado. Wi-Fi e BLE não são suportados.
- **Atualização pelo GitHub** só enxerga Releases de repositório **público** (veja `INSTRUCOES-GITHUB.md`).

## Como compilar
Envie o conteúdo desta pasta para a raiz do repositório e rode `Actions > Compilar Peugeot 308 APK`. O workflow só gera o APK se a assinatura bater com o certificado original (SHA-256 `531C7DF8…D62752`). Baixe `Peugeot308Launcher-1.20-v120-assinatura-original`.

Outros documentos: `docs/historico/README-V1.18.md` (CANBOX/OBD2), `docs/historico/README-INTEGRACAO-JANCAR.md`, `CHECKLIST-TESTE-CARRO.md`, `INSTRUCOES-GITHUB.md`.

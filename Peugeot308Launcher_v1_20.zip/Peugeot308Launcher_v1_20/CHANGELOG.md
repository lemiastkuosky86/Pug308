# Histórico de versões

## 1.20 — revisão geral
- **Volume**: o fade/mudo em andamento é concluído se a Activity for destruída (antes podia ficar em 0).
- **Manifest**: `configChanges` (a Activity não é mais recriada por mudança de tema/densidade/idioma da central), `BLUETOOTH_ADMIN` (para `cancelDiscovery()` do OBD2) e ícone do app.
- **Desempenho**: cache dos nomes de apps do dock (sem IPC por frame), formatadores de data/hora reutilizados, lista de Apps ordena/pesquisa sem recarregar nomes.
- **Atualização**: falha de consulta não repete a cada 10 min (espera ~1 h).
- **Clima**: sem código de tempo mostra `--` (antes "Poucas nuvens").
- **Textos**: aba Veículo atualizada (OBD2 fornece RPM, temperaturas e combustível).
- **GitHub Actions**: segredos da assinatura só nos dois steps que usam.
- Documentação antiga movida para `docs/historico/`.

## 1.19
Reconexão automática do OBD2, temperatura externa, diálogos sem barra do Android, clima por GPS só com coordenadas, motor de som sem BassBoost. Veja os detalhes em `README.md`.

## 1.18 / 1.16 / 1.15
Veja `docs/historico/`.
